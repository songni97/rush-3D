import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { WordItem, Student } from '../types';
import { WORKSHEET_WORDS, ALL_WORDS } from '../data/kvkvData';
import { WordIllustration } from './WordIllustration';
import { playSound, sebutPerkataan, beriPujianRawak, beriBimbinganRawak } from '../utils/speech';
import { recordAttempt } from '../utils/storage';
import { Volume2, CheckCircle2, RotateCcw, Sparkles, HelpCircle, ArrowRight, Award } from 'lucide-react';

interface Props {
  activeStudent: Student;
  soundEnabled: boolean;
  onStudentUpdated: () => void;
}

export const ActivitySheetMode: React.FC<Props> = ({
  activeStudent,
  soundEnabled,
  onStudentUpdated,
}) => {
  // State for answered items: wordId -> { answeredSyllable, isCorrect, attempts }
  const [answers, setAnswers] = useState<Record<string, { syllable: string; isCorrect: boolean; attempts: number }>>({});
  const [draggedSyllable, setDraggedSyllable] = useState<{ wordId: string; syllable: string } | null>(null);
  const [activeWordSet, setActiveWordSet] = useState<'buku' | 'semua'>('buku');
  const [focusedWordId, setFocusedWordId] = useState<string | null>(null);
  const [praiseText, setPraiseText] = useState<string | null>(null);

  const wordList = activeWordSet === 'buku' ? WORKSHEET_WORDS : ALL_WORDS;

  const handleSelectSyllable = (word: WordItem, chosen: string) => {
    playSound('pop');
    if (soundEnabled) {
      sebutPerkataan(chosen, 0.9);
    }

    const currentAttempt = answers[word.id]?.attempts || 0;
    const isCorrect = chosen.toLowerCase() === word.correctAnswer.toLowerCase();

    // Record attempt to teacher storage
    recordAttempt({
      studentId: activeStudent.id,
      studentName: activeStudent.name,
      wordId: word.id,
      word: word.word,
      targetSyllable: word.correctAnswer,
      chosenSyllable: chosen,
      isCorrect,
      timeSpentSeconds: 4,
      attemptsCount: currentAttempt + 1,
      mode: 'lembaran',
    });

    setAnswers((prev) => ({
      ...prev,
      [word.id]: {
        syllable: chosen,
        isCorrect,
        attempts: currentAttempt + 1,
      },
    }));

    if (isCorrect) {
      playSound('correct');
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
      });

      if (soundEnabled) {
        setTimeout(() => {
          sebutPerkataan(`${word.word}!`, 0.85);
          const praise = beriPujianRawak();
          setPraiseText(praise);
          setTimeout(() => setPraiseText(null), 3000);
        }, 600);
      }
      onStudentUpdated();
    } else {
      playSound('wrong');
      if (soundEnabled) {
        const msg = beriBimbinganRawak();
        setPraiseText(msg);
        setTimeout(() => setPraiseText(null), 3000);
      }
    }
  };

  const handleReset = () => {
    setAnswers({});
    setPraiseText(null);
    playSound('pop');
  };

  // Calculate completion
  const totalItems = wordList.length;
  const completedCorrect = wordList.filter((w) => answers[w.id]?.isCorrect).length;
  const progressPercent = Math.round((completedCorrect / totalItems) * 100);

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 font-century">
      {/* Worksheet Title Header matching physical activity sheet */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 shadow-md border-2 border-sky-200 mb-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-36 h-36 bg-amber-100 rounded-bl-full -mr-8 -mt-8 opacity-60 pointer-events-none" />
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 bg-sky-100 text-sky-800 text-xs font-bold px-3 py-1 rounded-full mb-2 border border-sky-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              Kemahiran Membaca Suku Kata KVKV
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              Baca dan pilih suku kata berdasarkan gambar.
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Tarik atau tekan suku kata yang betul ke dalam kotak untuk melengkapkan perkataan.
            </p>
          </div>

          {/* Quick controls: Filter set, Reset, Score */}
          <div className="flex items-center flex-wrap gap-2.5">
            <div className="bg-slate-100 p-1 rounded-xl flex items-center border border-slate-200 text-xs font-bold">
              <button
                onClick={() => { setActiveWordSet('buku'); handleReset(); }}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  activeWordSet === 'buku' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Set Lembaran Buku (6)
              </button>
              <button
                onClick={() => { setActiveWordSet('semua'); handleReset(); }}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  activeWordSet === 'semua' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Set Tambahan (18)
              </button>
            </div>

            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer border border-slate-300"
              title="Kosongkan jawapan dan cuba sekali lagi"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Mula Semula</span>
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-5 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="w-full sm:w-2/3">
            <div className="flex items-center justify-between text-xs font-bold mb-1.5">
              <span className="text-slate-700">Kemajuan Lembaran: {completedCorrect} daripada {totalItems} betul</span>
              <span className="text-sky-700">{progressPercent}%</span>
            </div>
            <div className="w-full bg-slate-200 h-3 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-amber-400 to-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {praiseText && (
            <div className="bg-amber-100 border border-amber-300 text-amber-900 px-3.5 py-1.5 rounded-full text-xs font-bold animate-bounce-gentle flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-600" />
              <span>{praiseText}</span>
            </div>
          )}
        </div>
      </div>

      {/* Grid of 6 or 18 Word Cards inspired by the physical worksheet layout */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
        {wordList.map((item, index) => {
          const ans = answers[item.id];
          const isSolved = ans?.isCorrect === true;
          const isWrong = ans?.isCorrect === false;

          return (
            <div
              key={item.id}
              className={`bg-white rounded-3xl p-5 shadow-sm border-3 transition-all relative flex flex-col items-center justify-between ${
                isSolved
                  ? 'border-emerald-500 bg-emerald-50/30 ring-4 ring-emerald-100'
                  : isWrong
                  ? 'border-rose-400 bg-rose-50/20'
                  : 'border-slate-200 hover:border-sky-300 hover:shadow-md'
              }`}
            >
              {/* Question Number Badge */}
              <div className="w-full flex items-center justify-between mb-2">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-900 text-white font-bold text-sm shadow-xs">
                  {index + 1}.
                </span>
                
                {/* Audio button for remedial listening */}
                <button
                  onClick={() => {
                    if (soundEnabled) {
                      sebutPerkataan(item.word, 0.85);
                    }
                  }}
                  className="flex items-center gap-1 text-slate-500 hover:text-sky-600 p-1.5 rounded-lg hover:bg-sky-50 transition cursor-pointer"
                  title="Dengar sebutan perkataan"
                >
                  <Volume2 className="w-4 h-4" />
                  <span className="text-xs font-semibold">Dengar</span>
                </button>
              </div>

              {/* Handcrafted Vector Illustration */}
              <div className="py-2 flex items-center justify-center min-h-[140px]">
                <WordIllustration type={item.svgType} size={130} />
              </div>

              {/* Syllable Options Clouds - exactly matching the 3-bubble arc in the user's worksheet */}
              <div className="w-full mt-3">
                <p className="text-[11px] font-bold text-slate-400 text-center uppercase tracking-wider mb-2">
                  Pilihan Suku Kata:
                </p>

                <div className="flex items-center justify-center gap-3">
                  {item.options.map((opt) => {
                    const isSelected = ans?.syllable === opt;
                    return (
                      <button
                        key={opt}
                        draggable
                        onDragStart={() => setDraggedSyllable({ wordId: item.id, syllable: opt })}
                        onDragEnd={() => setDraggedSyllable(null)}
                        onClick={() => handleSelectSyllable(item, opt)}
                        className={`h-12 w-12 sm:h-14 sm:w-14 rounded-full flex items-center justify-center text-lg sm:text-xl font-bold tracking-wide transition-all shadow-md active:scale-90 cursor-grab active:cursor-grabbing border-2 ${
                          isSelected && isSolved
                            ? 'bg-emerald-500 text-white border-emerald-600 scale-105 ring-2 ring-emerald-300'
                            : isSelected && isWrong
                            ? 'bg-rose-500 text-white border-rose-600 animate-shake'
                            : 'bg-white hover:bg-sky-50 text-slate-800 border-slate-300 hover:border-sky-500'
                        }`}
                        title={`Pilih suku kata "${opt}"`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Word Completion Container - matching the worksheet box with "gu _ _" or "_ _ bak" */}
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => {
                  if (draggedSyllable && draggedSyllable.wordId === item.id) {
                    handleSelectSyllable(item, draggedSyllable.syllable);
                  }
                }}
                className={`w-full mt-5 rounded-2xl border-2 p-3 text-center transition-all ${
                  isSolved
                    ? 'bg-emerald-100/70 border-emerald-400'
                    : isWrong
                    ? 'bg-rose-100/60 border-rose-300'
                    : 'bg-slate-50 border-dashed border-slate-300 hover:bg-sky-50/50'
                }`}
              >
                <div className="flex items-center justify-center gap-2 text-2xl sm:text-3xl font-black text-slate-800 tracking-wider">
                  {item.missingPosition === 2 ? (
                    <>
                      {/* Given prefix (e.g. "gu") */}
                      <span className="text-slate-900">{item.prefixDisplay}</span>
                      {/* Answer Slot */}
                      <div
                        className={`min-w-[70px] px-3 py-1 rounded-xl border-2 font-bold inline-flex items-center justify-center ${
                          isSolved
                            ? 'bg-emerald-600 text-white border-emerald-700'
                            : isWrong
                            ? 'bg-rose-600 text-white border-rose-700'
                            : 'bg-white text-slate-400 border-slate-300 border-dashed'
                        }`}
                      >
                        {ans ? ans.syllable : '_ _'}
                      </div>
                    </>
                  ) : (
                    <>
                      {/* Answer Slot at beginning (e.g. "_ _ bak") */}
                      <div
                        className={`min-w-[70px] px-3 py-1 rounded-xl border-2 font-bold inline-flex items-center justify-center ${
                          isSolved
                            ? 'bg-emerald-600 text-white border-emerald-700'
                            : isWrong
                            ? 'bg-rose-600 text-white border-rose-700'
                            : 'bg-white text-slate-400 border-slate-300 border-dashed'
                        }`}
                      >
                        {ans ? ans.syllable : '_ _'}
                      </div>
                      {/* Given suffix (e.g. "bak", "wan", "til") */}
                      <span className="text-slate-900">{item.suffixDisplay}</span>
                    </>
                  )}
                </div>

                {/* Status indicator note */}
                <div className="mt-2 text-xs font-semibold">
                  {isSolved && (
                    <span className="text-emerald-700 flex items-center justify-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      Tahniah! Betul: {item.word}
                    </span>
                  )}
                  {isWrong && (
                    <span className="text-rose-600">
                      Suku kata kurang tepat. Cuba lagi, adik!
                    </span>
                  )}
                  {!ans && (
                    <span className="text-slate-400">
                      Tarik atau tekan suku kata di atas
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Sheet Completion Reward Banner */}
      {completedCorrect === totalItems && (
        <div className="mt-10 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 rounded-3xl p-6 sm:p-8 text-center shadow-xl border-4 border-white animate-in zoom-in-95 duration-300">
          <div className="inline-block p-3 bg-white rounded-full shadow-md mb-3">
            <Award className="w-12 h-12 text-amber-600" />
          </div>
          <h3 className="text-2xl sm:text-3xl font-black text-amber-950">
            Syabas & Tahniah, {activeStudent.name}!
          </h3>
          <p className="text-base text-amber-900 font-semibold max-w-xl mx-auto mt-2">
            Adik telah berjaya melengkapkan semua suku kata pada lembaran aktiviti ini dengan cemerlang! ⭐ +{totalItems} Bintang dimasukkan ke dalam rekod pencapaian anda.
          </p>
          <div className="mt-5 flex items-center justify-center gap-3">
            <button
              onClick={handleReset}
              className="bg-amber-950 hover:bg-black text-white px-6 py-2.5 rounded-2xl text-sm font-bold shadow-md transition cursor-pointer"
            >
              Ulangi Lembaran
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
