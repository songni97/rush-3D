import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { WordItem, Student } from '../types';
import { ALL_WORDS } from '../data/kvkvData';
import { WordIllustration } from './WordIllustration';
import { playSound, sebutPerkataan, beriPujianRawak, beriBimbinganRawak } from '../utils/speech';
import { recordAttempt } from '../utils/storage';
import { Volume2, CheckCircle2, RotateCcw, ChevronLeft, ChevronRight, Sparkles, HelpCircle, Eye, EyeOff } from 'lucide-react';

interface Props {
  activeStudent: Student;
  soundEnabled: boolean;
  onStudentUpdated: () => void;
}

export const KVKVBuilderMode: React.FC<Props> = ({
  activeStudent,
  soundEnabled,
  onStudentUpdated,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [slot1, setSlot1] = useState<string | null>(null);
  const [slot2, setSlot2] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isError, setIsError] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [draggedItem, setDraggedItem] = useState<string | null>(null);
  const [showPhonicsColor, setShowPhonicsColor] = useState(true); // Konsonan biru, Vokal merah (Kaedah KPM)
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const currentWord: WordItem = ALL_WORDS[currentIndex];

  // Generate 4-6 shuffled syllable candidates including currentWord.syllable1 and currentWord.syllable2
  const [syllablePool, setSyllablePool] = useState<string[]>([]);

  useEffect(() => {
    // Generate distractors
    const pool = new Set<string>([currentWord.syllable1, currentWord.syllable2]);
    const others = ['da', 'bu', 'ka', 'li', 'ro', 'ti', 'ma', 'ta', 'su', 'ku', 'gi', 'pa'];
    for (const s of others) {
      if (pool.size >= 5) break;
      if (!pool.has(s)) pool.add(s);
    }
    const arr = Array.from(pool).sort(() => Math.random() - 0.5);
    setSyllablePool(arr);
    setSlot1(null);
    setSlot2(null);
    setIsSuccess(false);
    setIsError(false);
    setAttempts(0);
    setFeedbackMsg(null);
  }, [currentIndex]);

  const handlePlaceSyllable = (syllable: string) => {
    playSound('pop');
    if (soundEnabled) {
      sebutPerkataan(syllable, 0.9);
    }

    if (!slot1) {
      setSlot1(syllable);
      checkComplete(syllable, slot2);
    } else if (!slot2) {
      setSlot2(syllable);
      checkComplete(slot1, syllable);
    } else {
      // Both filled, replace slot 2
      setSlot2(syllable);
      checkComplete(slot1, syllable);
    }
  };

  const checkComplete = (s1: string | null, s2: string | null) => {
    if (!s1 || !s2) return;

    const combined = s1.toLowerCase() + s2.toLowerCase();
    const isCorrect =
      s1.toLowerCase() === currentWord.syllable1.toLowerCase() &&
      s2.toLowerCase() === currentWord.syllable2.toLowerCase();

    const newAttempts = attempts + 1;
    setAttempts(newAttempts);

    // Record to teacher logs
    recordAttempt({
      studentId: activeStudent.id,
      studentName: activeStudent.name,
      wordId: currentWord.id,
      word: currentWord.word,
      targetSyllable: currentWord.syllable2,
      chosenSyllable: s2,
      isCorrect,
      timeSpentSeconds: 5,
      attemptsCount: newAttempts,
      mode: 'cantum',
    });

    if (isCorrect) {
      setIsSuccess(true);
      setIsError(false);
      playSound('correct');
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 },
      });

      if (soundEnabled) {
        setTimeout(() => {
          sebutPerkataan(`${currentWord.word}!`, 0.85);
          const praise = beriPujianRawak();
          setFeedbackMsg(praise);
        }, 500);
      }
      onStudentUpdated();
    } else {
      setIsError(true);
      playSound('wrong');
      if (soundEnabled) {
        const msg = beriBimbinganRawak();
        setFeedbackMsg(msg);
      }
    }
  };

  const handleNextWord = () => {
    playSound('pop');
    if (currentIndex < ALL_WORDS.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const handlePrevWord = () => {
    playSound('pop');
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  const clearSlot = (slotNum: 1 | 2) => {
    playSound('pop');
    if (slotNum === 1) setSlot1(null);
    if (slotNum === 2) setSlot2(null);
    setIsSuccess(false);
    setIsError(false);
    setFeedbackMsg(null);
  };

  // Render letters with KPM phonics coloring: Consonants (blue), Vowels (red)
  const renderPhonicsText = (text: string) => {
    if (!showPhonicsColor) return <span>{text}</span>;
    const vowels = new Set(['a', 'e', 'i', 'o', 'u']);
    return (
      <span>
        {text.split('').map((char, i) => (
          <span
            key={i}
            className={vowels.has(char.toLowerCase()) ? 'text-red-500 font-extrabold' : 'text-blue-600 font-extrabold'}
          >
            {char}
          </span>
        ))}
      </span>
    );
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 font-century">
      {/* Top Controller */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border-2 border-sky-200 mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-sky-600 text-white font-bold text-sm">
            {currentIndex + 1}
          </span>
          <div>
            <h3 className="text-base font-bold text-slate-800">
              Cantum Suku Kata (KV + KV)
            </h3>
            <p className="text-xs text-slate-500">
              Perkataan {currentIndex + 1} daripada {ALL_WORDS.length}
            </p>
          </div>
        </div>

        {/* Phonics Color Switcher & Navigation */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowPhonicsColor(!showPhonicsColor)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer border ${
              showPhonicsColor
                ? 'bg-amber-100 border-amber-300 text-amber-900'
                : 'bg-slate-100 border-slate-300 text-slate-600'
            }`}
            title="Kaedah Warna KPM: Konsonan Biru, Vokal Merah"
          >
            {showPhonicsColor ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>Warna Suku Kata KPM</span>
          </button>

          <div className="flex items-center gap-1">
            <button
              onClick={handlePrevWord}
              disabled={currentIndex === 0}
              className="p-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 transition cursor-pointer text-slate-700"
              title="Perkataan sebelum"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleNextWord}
              className="flex items-center gap-1 bg-sky-600 hover:bg-sky-700 text-white px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer shadow-xs"
              title="Perkataan seterusnya"
            >
              <span>Seterusnya</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Activity Card */}
      <div
        className={`bg-white rounded-3xl p-6 sm:p-8 shadow-md border-3 transition-all relative ${
          isSuccess
            ? 'border-emerald-500 bg-emerald-50/40 ring-4 ring-emerald-200'
            : isError
            ? 'border-rose-400 bg-rose-50/30'
            : 'border-slate-200'
        }`}
      >
        {/* Feedback message banner */}
        {feedbackMsg && (
          <div
            className={`mb-6 p-3 rounded-2xl text-center text-sm font-bold animate-bounce-gentle flex items-center justify-center gap-2 border ${
              isSuccess
                ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                : 'bg-rose-100 text-rose-800 border-rose-300'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>{feedbackMsg}</span>
          </div>
        )}

        {/* Center: Large Clear Picture & Listen Button */}
        <div className="flex flex-col items-center justify-center py-2">
          <div className="relative p-4 rounded-3xl bg-slate-50 border-2 border-slate-100 shadow-inner">
            <WordIllustration type={currentWord.svgType} size={160} />
            <button
              onClick={() => {
                if (soundEnabled) {
                  sebutPerkataan(currentWord.word, 0.85);
                }
              }}
              className="absolute -bottom-2 -right-2 bg-sky-600 hover:bg-sky-700 text-white p-2.5 rounded-full shadow-lg transition active:scale-90 cursor-pointer"
              title="Dengar perkataan"
            >
              <Volume2 className="w-5 h-5" />
            </button>
          </div>

          <p className="text-sm font-semibold text-slate-500 mt-3 text-center max-w-sm">
            {currentWord.meaning}
          </p>
        </div>

        {/* Word Construction Drop Target Slots */}
        <div className="mt-8 flex flex-col items-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">
            Cantumkan 2 suku kata untuk membina perkataan:
          </p>

          <div className="flex items-center gap-3 sm:gap-4 flex-wrap justify-center">
            {/* Slot 1 */}
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => {
                if (draggedItem) {
                  handlePlaceSyllable(draggedItem);
                }
              }}
              onClick={() => slot1 && clearSlot(1)}
              className={`h-20 w-24 sm:h-24 sm:w-28 rounded-2xl border-3 flex flex-col items-center justify-center cursor-pointer transition-all shadow-sm ${
                slot1
                  ? 'bg-white border-sky-500 shadow-md ring-2 ring-sky-100'
                  : 'bg-slate-50 border-dashed border-slate-300 hover:bg-sky-50/50'
              }`}
            >
              {slot1 ? (
                <>
                  <span className="text-3xl sm:text-4xl font-black">
                    {renderPhonicsText(slot1)}
                  </span>
                  <span className="text-[10px] text-slate-400 mt-0.5 font-medium">Tekan padam</span>
                </>
              ) : (
                <span className="text-xs font-bold text-slate-400">Suku Kata 1</span>
              )}
            </div>

            <span className="text-3xl font-black text-slate-300">+</span>

            {/* Slot 2 */}
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => {
                if (draggedItem) {
                  handlePlaceSyllable(draggedItem);
                }
              }}
              onClick={() => slot2 && clearSlot(2)}
              className={`h-20 w-24 sm:h-24 sm:w-28 rounded-2xl border-3 flex flex-col items-center justify-center cursor-pointer transition-all shadow-sm ${
                slot2
                  ? 'bg-white border-sky-500 shadow-md ring-2 ring-sky-100'
                  : 'bg-slate-50 border-dashed border-slate-300 hover:bg-sky-50/50'
              }`}
            >
              {slot2 ? (
                <>
                  <span className="text-3xl sm:text-4xl font-black">
                    {renderPhonicsText(slot2)}
                  </span>
                  <span className="text-[10px] text-slate-400 mt-0.5 font-medium">Tekan padam</span>
                </>
              ) : (
                <span className="text-xs font-bold text-slate-400">Suku Kata 2</span>
              )}
            </div>

            <span className="text-3xl font-black text-slate-300">=</span>

            {/* Result Word Box */}
            <div
              className={`min-h-[80px] px-5 sm:px-6 py-3 rounded-2xl border-2 flex items-center justify-center transition-all ${
                isSuccess
                  ? 'bg-emerald-600 text-white border-emerald-700 shadow-lg scale-105'
                  : 'bg-slate-100 text-slate-400 border-slate-200'
              }`}
            >
              <span className="text-3xl sm:text-4xl font-black tracking-wider">
                {isSuccess ? currentWord.word : (slot1 && slot2 ? `${slot1}${slot2}` : '...?')}
              </span>
            </div>
          </div>
        </div>

        {/* Syllables Bank (Peti Suku Kata) */}
        <div className="mt-8 pt-6 border-t border-slate-100">
          <p className="text-xs font-bold text-slate-500 text-center mb-3">
            Peti Suku Kata (Tarik atau tekan suku kata untuk memilih):
          </p>

          <div className="flex items-center justify-center flex-wrap gap-3">
            {syllablePool.map((syllable, idx) => (
              <button
                key={idx}
                draggable
                onDragStart={() => setDraggedItem(syllable)}
                onDragEnd={() => setDraggedItem(null)}
                onClick={() => handlePlaceSyllable(syllable)}
                className="h-14 w-16 sm:h-16 sm:w-20 rounded-2xl bg-gradient-to-b from-white to-sky-50 hover:to-amber-50 text-slate-800 border-2 border-slate-300 hover:border-sky-500 shadow-md flex items-center justify-center text-2xl font-bold tracking-wide active:scale-95 transition cursor-grab active:cursor-grabbing hover:shadow-lg"
              >
                {renderPhonicsText(syllable)}
              </button>
            ))}
          </div>
        </div>

        {/* Action Controls */}
        <div className="mt-8 flex items-center justify-between pt-4 border-t border-slate-100">
          <button
            onClick={() => {
              setSlot1(null);
              setSlot2(null);
              setIsSuccess(false);
              setIsError(false);
              setFeedbackMsg(null);
              playSound('pop');
            }}
            className="flex items-center gap-1.5 text-slate-500 hover:text-slate-800 text-xs font-bold px-3 py-2 rounded-xl hover:bg-slate-100 transition cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Kosongkan Kotak</span>
          </button>

          {isSuccess && (
            <button
              onClick={handleNextWord}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-2.5 rounded-xl text-sm shadow-md transition flex items-center gap-2 cursor-pointer animate-pulse-ring"
            >
              <span>Perkataan Seterusnya</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
