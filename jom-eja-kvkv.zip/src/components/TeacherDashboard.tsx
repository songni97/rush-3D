import React, { useState } from 'react';
import { Student, AttemptLog } from '../types';
import { getStudents, getAttemptLogs, calculateStudentStats, exportBorangTransitCSV, resetAllData, saveStudents } from '../utils/storage';
import {
  Users,
  Award,
  AlertTriangle,
  CheckCircle,
  FileSpreadsheet,
  Printer,
  RotateCcw,
  X,
  Search,
  Filter,
  TrendingUp,
  Brain,
  Sparkles,
  ClipboardList,
  UserCheck,
  ChevronRight,
  BookOpen,
} from 'lucide-react';

interface Props {
  onClose: () => void;
  onStudentSelected: (studentId: string) => void;
}

export const TeacherDashboard: React.FC<Props> = ({ onClose, onStudentSelected }) => {
  const [students, setStudents] = useState<Student[]>(getStudents());
  const [logs, setLogs] = useState<AttemptLog[]>(getAttemptLogs());
  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || '');
  const [searchTerm, setSearchTerm] = useState('');
  const [teacherNoteInput, setTeacherNoteInput] = useState('');
  const [customNotes, setCustomNotes] = useState<Record<string, string>>({});
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  // Aggregated Analytics
  const totalStudents = students.length;
  const studentStatsList = students.map((s) => ({
    student: s,
    stats: calculateStudentStats(s.id),
  }));

  const totalAttemptsAll = logs.length;
  const correctAttemptsAll = logs.filter((l) => l.isCorrect).length;
  const classAverageAccuracy = totalAttemptsAll > 0 ? Math.round((correctAttemptsAll / totalAttemptsAll) * 100) : 0;

  const masteredCount = studentStatsList.filter((s) => s.stats.pbdLevel >= 4).length;
  const interventionCount = studentStatsList.filter((s) => s.stats.pbdLevel <= 2).length;

  // Syllable Error Aggregation (Item Analysis)
  const errorMap: Record<string, { count: number; words: Set<string> }> = {};
  logs.filter((l) => !l.isCorrect).forEach((l) => {
    if (!errorMap[l.targetSyllable]) {
      errorMap[l.targetSyllable] = { count: 0, words: new Set() };
    }
    errorMap[l.targetSyllable].count += 1;
    errorMap[l.targetSyllable].words.add(l.word);
  });

  const topTroubleSyllables = Object.keys(errorMap)
    .map((syl) => ({
      syllable: syl,
      count: errorMap[syl].count,
      words: Array.from(errorMap[syl].words),
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);

  // Filtered Students
  const filteredStudents = studentStatsList.filter(
    (item) =>
      item.student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.student.className.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedItem = studentStatsList.find((item) => item.student.id === selectedStudentId);

  // Actions
  const handleDownloadCSV = () => {
    const csvContent = exportBorangTransitCSV(students);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Borang_Transit_PBD_KVKV_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleResetData = () => {
    resetAllData();
    setStudents(getStudents());
    setLogs(getAttemptLogs());
    setShowConfirmReset(false);
  };

  const handleSaveTeacherNote = (studentId: string) => {
    if (!teacherNoteInput.trim()) return;
    setCustomNotes((prev) => ({ ...prev, [studentId]: teacherNoteInput.trim() }));
    setTeacherNoteInput('');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs font-century flex justify-center p-2 sm:p-4">
      <div className="bg-white w-full max-w-6xl rounded-3xl shadow-2xl flex flex-col my-auto border-2 border-indigo-200 overflow-hidden max-h-[94vh]">
        {/* Dashboard Top Header */}
        <div className="bg-gradient-to-r from-indigo-700 via-indigo-600 to-sky-700 text-white p-5 sm:p-6 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 text-white border border-white/30 shadow-inner">
              <ClipboardList className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
                  Dashboard Analitik Guru Pemulihan Khas
                </h2>
                <span className="hidden sm:inline-block bg-amber-400 text-slate-950 text-xs font-black px-2.5 py-0.5 rounded-full">
                  PBD Bahasa Melayu
                </span>
              </div>
              <p className="text-xs text-indigo-100 font-medium mt-0.5">
                Konstruk 3: Kemahiran Mengecam, Membaca & Membina Suku Kata Terbuka KVKV
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 text-white px-3 py-2 rounded-xl text-xs font-bold transition border border-white/20 cursor-pointer"
              title="Cetak Borang Transit PBD KPM"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">Cetak Rekod</span>
            </button>

            <button
              onClick={handleDownloadCSV}
              className="flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-600 text-white px-3 py-2 rounded-xl text-xs font-bold transition shadow-sm cursor-pointer"
              title="Muat turun borang ke format Excel / CSV"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span className="hidden sm:inline">Muat Turun CSV</span>
            </button>

            <button
              onClick={() => setShowConfirmReset(true)}
              className="flex items-center gap-1.5 bg-rose-500/20 hover:bg-rose-500/40 text-rose-100 px-3 py-2 rounded-xl text-xs font-bold transition border border-rose-300/30 cursor-pointer"
              title="Tetapan semula data percubaan"
            >
              <RotateCcw className="w-4 h-4" />
              <span className="hidden sm:inline">Set Semula</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/20 hover:bg-white/30 text-white transition cursor-pointer ml-1"
              title="Tutup Dashboard"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Dashboard Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6">
          {/* Confirmation modal for reset */}
          {showConfirmReset && (
            <div className="bg-rose-50 border-2 border-rose-300 p-4 rounded-2xl flex items-center justify-between gap-4 animate-in fade-in duration-200">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0" />
                <p className="text-xs text-rose-900 font-semibold">
                  Adakah Cikgu pasti mahu menetapkan semula semua data latihan dan rekod murid? Data akan kembali ke tetapan asal.
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => setShowConfirmReset(false)}
                  className="bg-white border border-slate-300 text-slate-700 px-3 py-1.5 rounded-lg text-xs font-bold"
                >
                  Batal
                </button>
                <button
                  onClick={handleResetData}
                  className="bg-rose-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-rose-700"
                >
                  Ya, Set Semula
                </button>
              </div>
            </div>
          )}

          {/* 4 Key Executive Performance Indicators */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {/* 1. Total Remedial Students */}
            <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-4">
              <div className="flex items-center justify-between text-slate-500 mb-1">
                <span className="text-xs font-bold uppercase tracking-wider">Murid Pemulihan</span>
                <Users className="w-4 h-4 text-indigo-600" />
              </div>
              <p className="text-2xl sm:text-3xl font-black text-slate-900">{totalStudents} Orang</p>
              <p className="text-[11px] text-slate-500 font-medium mt-1">
                Tahun 2 & Tahun 3 KPM
              </p>
            </div>

            {/* 2. Class Accuracy Average */}
            <div className="bg-sky-50 border-2 border-sky-200 rounded-2xl p-4">
              <div className="flex items-center justify-between text-sky-700 mb-1">
                <span className="text-xs font-bold uppercase tracking-wider">Ketepatan Purata</span>
                <TrendingUp className="w-4 h-4 text-sky-600" />
              </div>
              <p className="text-2xl sm:text-3xl font-black text-sky-950">{classAverageAccuracy}%</p>
              <p className="text-[11px] text-sky-700 font-medium mt-1">
                Berdasarkan {totalAttemptsAll} percubaan
              </p>
            </div>

            {/* 3. Students Mastered (TP4 - TP6) */}
            <div className="bg-emerald-50 border-2 border-emerald-200 rounded-2xl p-4">
              <div className="flex items-center justify-between text-emerald-700 mb-1">
                <span className="text-xs font-bold uppercase tracking-wider">Telah Menguasai</span>
                <CheckCircle className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="text-2xl sm:text-3xl font-black text-emerald-950">{masteredCount} Murid</p>
              <p className="text-[11px] text-emerald-700 font-medium mt-1">
                Tahap Penguasaan TP4 - TP6
              </p>
            </div>

            {/* 4. Need Targeted Intervention (TP1 - TP2) */}
            <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl p-4">
              <div className="flex items-center justify-between text-amber-700 mb-1">
                <span className="text-xs font-bold uppercase tracking-wider">Perlu Intervensi</span>
                <AlertTriangle className="w-4 h-4 text-amber-600" />
              </div>
              <p className="text-2xl sm:text-3xl font-black text-amber-950">{interventionCount} Murid</p>
              <p className="text-[11px] text-amber-700 font-medium mt-1">
                Tahap Penguasaan TP1 - TP2
              </p>
            </div>
          </div>

          {/* Item Analysis & Trouble Syllables Section (Analisis Ralat untuk RPH) */}
          <div className="bg-white rounded-2xl border-2 border-amber-200 p-5 shadow-xs">
            <div className="flex items-center gap-2 mb-3">
              <Brain className="w-5 h-5 text-amber-600" />
              <h3 className="text-sm sm:text-base font-bold text-slate-900">
                Analisis Ralat: Suku Kata Paling Kerap Silap (Item Analysis untuk Intervensi Guru)
              </h3>
            </div>
            <p className="text-xs text-slate-600 mb-4 font-medium">
              Data ini membantu guru merancang aktiviti bimbingan berfokus dalam Rancangan Pengajaran Harian (RPH) bagi mengatasi kekeliruan vokal dan suku kata murid.
            </p>

            {topTroubleSyllables.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {topTroubleSyllables.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xl font-black text-amber-950 bg-amber-200/80 px-3 py-1 rounded-lg">
                        "{item.syllable}"
                      </span>
                      <span className="text-xs font-bold text-rose-600 bg-rose-100 px-2 py-0.5 rounded-full">
                        {item.count} kali salah
                      </span>
                    </div>
                    <div className="mt-2 text-[11px] text-slate-600">
                      <strong>Perkataan Terlibat:</strong> {item.words.join(', ')}
                    </div>
                    <p className="mt-1 text-[10px] text-amber-800 font-semibold italic">
                      Cadangan: Latih tubi perbezaan vokal 'a', 'i', 'u' secara fonik bergambar.
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-emerald-700 font-bold bg-emerald-50 p-3 rounded-xl">
                Tiada rekod kesilapan ketara buat masa ini. Semua murid menunjukkan kemajuan baik!
              </p>
            )}
          </div>

          {/* Main Layout: Student Selection & Detailed Card */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Student List & Search (4 Cols) */}
            <div className="lg:col-span-5 bg-white rounded-2xl border-2 border-slate-200 p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-indigo-600" />
                  Senarai Murid Pemulihan
                </h3>
                <span className="text-xs text-slate-500 font-semibold">{filteredStudents.length} murid</span>
              </div>

              {/* Search input */}
              <div className="relative mb-3">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Cari nama murid atau kelas..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-400"
                />
              </div>

              {/* List */}
              <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                {filteredStudents.map(({ student, stats }) => {
                  const isSelected = student.id === selectedStudentId;
                  return (
                    <button
                      key={student.id}
                      onClick={() => setSelectedStudentId(student.id)}
                      className={`w-full p-3 rounded-xl border text-left transition flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-50 border-indigo-400 ring-2 ring-indigo-100'
                          : 'bg-white hover:bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{student.avatar}</span>
                        <div>
                          <p className="text-xs font-bold text-slate-900 leading-tight">
                            {student.name}
                          </p>
                          <p className="text-[10px] text-slate-500 font-medium">
                            {student.className} • ⭐ {student.stars} Bintang
                          </p>
                        </div>
                      </div>

                      <div className="text-right flex flex-col items-end">
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                            stats.pbdLevel >= 4
                              ? 'bg-emerald-100 text-emerald-800'
                              : stats.pbdLevel === 3
                              ? 'bg-sky-100 text-sky-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          TP{stats.pbdLevel}
                        </span>
                        <span className="text-[10px] text-slate-500 font-bold mt-1">
                          {stats.accuracyRate}%
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Right Column: Individual Student Detailed Card (7 Cols) */}
            <div className="lg:col-span-7 bg-white rounded-2xl border-2 border-slate-200 p-5">
              {selectedItem ? (
                <div>
                  {/* Student Header */}
                  <div className="flex flex-wrap items-start justify-between gap-3 pb-4 border-b border-slate-100">
                    <div className="flex items-center gap-3">
                      <span className="text-4xl p-2 bg-sky-50 rounded-2xl border border-sky-100">
                        {selectedItem.student.avatar}
                      </span>
                      <div>
                        <h3 className="text-base sm:text-lg font-bold text-slate-900">
                          {selectedItem.student.name}
                        </h3>
                        <p className="text-xs text-slate-500 font-medium">
                          Kelas: {selectedItem.student.className} • No. ID: {selectedItem.student.id}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          onStudentSelected(selectedItem.student.id);
                          onClose();
                        }}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer flex items-center gap-1"
                        title="Pilih murid ini untuk mula aktiviti"
                      >
                        <span>Pilih Murid Ini</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Individual Metrics */}
                  <div className="grid grid-cols-3 gap-2.5 my-4">
                    <div className="bg-sky-50 p-2.5 rounded-xl border border-sky-100 text-center">
                      <p className="text-[10px] text-sky-700 font-bold uppercase">Tahap Penguasaan</p>
                      <p className="text-xl font-black text-sky-900 mt-0.5">TP{selectedItem.stats.pbdLevel}</p>
                      <p className="text-[10px] text-sky-800 font-semibold">{selectedItem.stats.pbdStatus}</p>
                    </div>

                    <div className="bg-emerald-50 p-2.5 rounded-xl border border-emerald-100 text-center">
                      <p className="text-[10px] text-emerald-700 font-bold uppercase">Ketepatan</p>
                      <p className="text-xl font-black text-emerald-900 mt-0.5">{selectedItem.stats.accuracyRate}%</p>
                      <p className="text-[10px] text-emerald-700 font-semibold">{selectedItem.stats.correctAttempts}/{selectedItem.stats.totalAttempts} Betul</p>
                    </div>

                    <div className="bg-amber-50 p-2.5 rounded-xl border border-amber-100 text-center">
                      <p className="text-[10px] text-amber-700 font-bold uppercase">Bintang & Markah</p>
                      <p className="text-xl font-black text-amber-900 mt-0.5">⭐ {selectedItem.student.stars}</p>
                      <p className="text-[10px] text-amber-800 font-semibold">{selectedItem.student.totalScore} Mata</p>
                    </div>
                  </div>

                  {/* Mastered vs Needing Practice Words */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                    <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-200">
                      <p className="text-xs font-bold text-emerald-800 flex items-center gap-1.5 mb-1.5">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                        Perkataan Dikuasai:
                      </p>
                      {selectedItem.stats.masteredWords.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {selectedItem.stats.masteredWords.map((w) => (
                            <span key={w} className="bg-white border border-emerald-200 text-emerald-900 px-2 py-0.5 rounded-md text-[11px] font-bold">
                              {w}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-[11px] text-slate-500 italic">Sedang dalam proses penilaian awal.</p>
                      )}
                    </div>

                    <div className="bg-rose-50/60 p-3 rounded-xl border border-rose-200">
                      <p className="text-xs font-bold text-rose-800 flex items-center gap-1.5 mb-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                        Perlu Intervensi Khas:
                      </p>
                      {selectedItem.stats.wordsNeedingPractice.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {selectedItem.stats.wordsNeedingPractice.map((w) => (
                            <span key={w} className="bg-white border border-rose-200 text-rose-900 px-2 py-0.5 rounded-md text-[11px] font-bold">
                              {w}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-[11px] text-emerald-700 font-medium">Tiada kelemahan ketara.</p>
                      )}
                    </div>
                  </div>

                  {/* Teacher's Pedagogical Notes and Recommendations */}
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 mb-4">
                    <p className="text-xs font-bold text-slate-700 mb-1">
                      Catatan Perkembangan PBD (Automatik KPM):
                    </p>
                    <p className="text-xs text-slate-600 font-medium leading-relaxed">
                      {selectedItem.stats.notes}
                    </p>

                    {/* Custom Teacher Note */}
                    <div className="mt-3 pt-3 border-t border-slate-200">
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">
                        Catatan Manual Guru Pemulihan:
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder={customNotes[selectedItem.student.id] || 'Contoh: Murid sangat berminat dengan lembaran guli...'}
                          value={teacherNoteInput}
                          onChange={(e) => setTeacherNoteInput(e.target.value)}
                          className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                        />
                        <button
                          onClick={() => handleSaveTeacherNote(selectedItem.student.id)}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer"
                        >
                          Simpan
                        </button>
                      </div>
                      {customNotes[selectedItem.student.id] && (
                        <p className="text-[11px] text-indigo-900 font-semibold mt-1">
                          ✓ Tersimpan: "{customNotes[selectedItem.student.id]}"
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Recent Attempt Logs for this student */}
                  <div>
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                      Log Aktiviti Terkini Murid:
                    </p>
                    <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                      {logs
                        .filter((l) => l.studentId === selectedItem.student.id)
                        .slice(0, 8)
                        .map((l) => (
                          <div
                            key={l.id}
                            className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200 text-xs"
                          >
                            <div className="flex items-center gap-2">
                              <span
                                className={`flex h-4 w-4 items-center justify-center rounded-full text-[10px] font-bold text-white ${
                                  l.isCorrect ? 'bg-emerald-500' : 'bg-rose-500'
                                }`}
                              >
                                {l.isCorrect ? '✓' : '✗'}
                              </span>
                              <span className="font-bold text-slate-800">{l.word}</span>
                              <span className="text-[11px] text-slate-400">
                                (Pilih: {l.chosenSyllable || '-'})
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400 font-medium">
                              Mod {l.mode} • {new Date(l.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-full flex items-center justify-center text-slate-400 text-xs">
                  Sila pilih murid dari senarai di sebelah kiri.
                </div>
              )}
            </div>
          </div>

          {/* Official KPM PBD Transit Table (Print Friendly) */}
          <div className="bg-white rounded-2xl border-2 border-slate-200 p-5 overflow-x-auto print:block">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  Borang Transit Pentaksiran Bilik Darjah (PBD) - Kemahiran KVKV
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Standard Kandungan: 2.1 Asas Membaca dan Memahami Suku Kata Terbuka KVKV
                </p>
              </div>
            </div>

            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 border-y border-slate-300 text-slate-700 font-bold uppercase text-[10px] tracking-wider">
                  <th className="py-2.5 px-3">Bil.</th>
                  <th className="py-2.5 px-3">Nama Murid</th>
                  <th className="py-2.5 px-3">Kelas</th>
                  <th className="py-2.5 px-3 text-center">Bintang ⭐</th>
                  <th className="py-2.5 px-3 text-center">Ketepatan</th>
                  <th className="py-2.5 px-3 text-center">Tahap (TP)</th>
                  <th className="py-2.5 px-3">Status Penguasaan</th>
                  <th className="py-2.5 px-3">Cadangan Tindakan Susulan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {students.map((st, idx) => {
                  const stats = calculateStudentStats(st.id);
                  return (
                    <tr key={st.id} className="hover:bg-slate-50 transition">
                      <td className="py-2.5 px-3 font-bold text-slate-500">{idx + 1}</td>
                      <td className="py-2.5 px-3 font-bold text-slate-900 flex items-center gap-1.5">
                        <span>{st.avatar}</span>
                        <span>{st.name}</span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 font-medium">{st.className}</td>
                      <td className="py-2.5 px-3 text-center font-bold text-amber-600">{st.stars}</td>
                      <td className="py-2.5 px-3 text-center font-bold text-slate-700">{stats.accuracyRate}%</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className="bg-indigo-100 text-indigo-900 font-black px-2 py-0.5 rounded text-[11px]">
                          TP{stats.pbdLevel}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-bold">
                        <span
                          className={
                            stats.pbdStatus === 'Telah Menguasai'
                              ? 'text-emerald-700'
                              : stats.pbdStatus === 'Sedang Menguasai'
                              ? 'text-sky-700'
                              : 'text-rose-600'
                          }
                        >
                          {stats.pbdStatus}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-500 text-[11px] max-w-xs truncate">
                        {customNotes[st.id] || stats.notes}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
