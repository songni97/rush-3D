import React, { useState } from 'react';
import { ALL_WORDS } from '../data/kvkvData';
import { WordIllustration } from './WordIllustration';
import { playSound, sebutPerkataan } from '../utils/speech';
import { Volume2, ChevronLeft, ChevronRight, Shuffle, Sparkles, BookOpen } from 'lucide-react';

interface Props {
  soundEnabled: boolean;
}

export const FlashcardsMode: React.FC<Props> = ({ soundEnabled }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const word = ALL_WORDS[currentIndex];

  const handleNext = () => {
    playSound('pop');
    setCurrentIndex((prev) => (prev < ALL_WORDS.length - 1 ? prev + 1 : 0));
  };

  const handlePrev = () => {
    playSound('pop');
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : ALL_WORDS.length - 1));
  };

  const handleShuffle = () => {
    playSound('pop');
    const randomIdx = Math.floor(Math.random() * ALL_WORDS.length);
    setCurrentIndex(randomIdx);
  };

  const handlePronounce = (text: string) => {
    if (soundEnabled) {
      sebutPerkataan(text, 0.85);
    }
  };

  // KPM Phonics coloring
  const vowels = new Set(['a', 'e', 'i', 'o', 'u']);
  const colorize = (syllable: string) => {
    return (
      <span>
        {syllable.split('').map((c, i) => (
          <span key={i} className={vowels.has(c.toLowerCase()) ? 'text-rose-500 font-black' : 'text-blue-600 font-black'}>
            {c}
          </span>
        ))}
      </span>
    );
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 font-century">
      {/* Title */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center gap-1.5 bg-sky-100 text-sky-800 px-3 py-1 rounded-full text-xs font-bold mb-2 border border-sky-200">
          <BookOpen className="w-3.5 h-3.5 text-sky-600" />
          Bimbingan Membaca & Mengeja
        </div>
        <h2 className="text-2xl font-black text-slate-900">
          Kad Imbasan Bersuara KVKV
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          Tekan mana-mana suku kata atau butang pembesar suara untuk mendengar sebutan fonik Melayu.
        </p>
      </div>

      {/* Main Flashcard */}
      <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-xl border-3 border-sky-200 text-center relative overflow-hidden">
        {/* Counter Tag */}
        <div className="absolute top-4 left-4 bg-slate-100 text-slate-700 px-3 py-1 rounded-full text-xs font-bold border border-slate-200">
          Kad {currentIndex + 1} / {ALL_WORDS.length}
        </div>

        {/* Big Illustration */}
        <div className="py-6 flex items-center justify-center">
          <div className="p-4 rounded-3xl bg-slate-50 border-2 border-slate-100 shadow-inner">
            <WordIllustration type={word.svgType} size={180} />
          </div>
        </div>

        {/* Syllable Breakdown Buttons */}
        <div className="flex items-center justify-center gap-4 my-4">
          {/* Syllable 1 */}
          <button
            onClick={() => handlePronounce(word.syllable1)}
            className="px-6 py-3 rounded-2xl bg-slate-50 hover:bg-sky-50 border-2 border-slate-300 hover:border-sky-400 text-4xl sm:text-5xl font-black shadow-md transition active:scale-95 cursor-pointer flex flex-col items-center"
            title={`Tekan untuk dengar bunyi "${word.syllable1}"`}
          >
            {colorize(word.syllable1)}
            <span className="text-[10px] text-slate-400 font-bold mt-1">Suku Kata 1</span>
          </button>

          <span className="text-3xl font-black text-slate-300">+</span>

          {/* Syllable 2 */}
          <button
            onClick={() => handlePronounce(word.syllable2)}
            className="px-6 py-3 rounded-2xl bg-slate-50 hover:bg-sky-50 border-2 border-slate-300 hover:border-sky-400 text-4xl sm:text-5xl font-black shadow-md transition active:scale-95 cursor-pointer flex flex-col items-center"
            title={`Tekan untuk dengar bunyi "${word.syllable2}"`}
          >
            {colorize(word.syllable2)}
            <span className="text-[10px] text-slate-400 font-bold mt-1">Suku Kata 2</span>
          </button>
        </div>

        {/* Full Word Pronunciation Card */}
        <div className="mt-6 p-4 rounded-2xl bg-sky-50 border border-sky-200 flex items-center justify-between">
          <div className="text-left">
            <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Perkataan Penuh:</p>
            <p className="text-3xl font-black text-slate-900 tracking-wide">{word.word}</p>
          </div>

          <button
            onClick={() => handlePronounce(word.word)}
            className="flex items-center gap-2 bg-sky-600 hover:bg-sky-700 text-white px-4 py-2.5 rounded-xl text-sm font-bold shadow-md transition active:scale-95 cursor-pointer"
          >
            <Volume2 className="w-5 h-5" />
            <span>Sebut Kata</span>
          </button>
        </div>

        {/* Meaning / Sentence */}
        <p className="text-xs sm:text-sm text-slate-600 mt-4 italic font-medium">
          "{word.meaning}"
        </p>
      </div>

      {/* Navigation Controls */}
      <div className="mt-6 flex items-center justify-between">
        <button
          onClick={handlePrev}
          className="flex items-center gap-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 px-4 py-2.5 rounded-2xl text-xs font-bold shadow-xs transition cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Sebelum</span>
        </button>

        <button
          onClick={handleShuffle}
          className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-white px-4 py-2.5 rounded-2xl text-xs font-bold shadow-xs transition cursor-pointer"
          title="Kocok kad secara rawak"
        >
          <Shuffle className="w-4 h-4" />
          <span>Kad Rawak</span>
        </button>

        <button
          onClick={handleNext}
          className="flex items-center gap-2 bg-sky-600 hover:bg-sky-700 text-white px-4 py-2.5 rounded-2xl text-xs font-bold shadow-xs transition cursor-pointer"
        >
          <span>Seterusnya</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
