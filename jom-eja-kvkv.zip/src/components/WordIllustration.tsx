import React from 'react';

interface Props {
  type: string;
  className?: string;
  size?: number;
}

export const WordIllustration: React.FC<Props> = ({ type, className = '', size = 120 }) => {
  switch (type) {
    case 'guli':
      // 3 glass marbles with swirls matching worksheet #1
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          <defs>
            <radialGradient id="marble1" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stop-color="#ffffff" />
              <stop offset="60%" stop-color="#bae6fd" />
              <stop offset="100%" stop-color="#0284c7" />
            </radialGradient>
            <radialGradient id="marble2" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stop-color="#ffffff" />
              <stop offset="60%" stop-color="#fed7aa" />
              <stop offset="100%" stop-color="#ea580c" />
            </radialGradient>
            <radialGradient id="marble3" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stop-color="#ffffff" />
              <stop offset="60%" stop-color="#bbf7d0" />
              <stop offset="100%" stop-color="#16a34a" />
            </radialGradient>
          </defs>
          {/* Top/Back marble */}
          <circle cx="105" cy="55" r="38" fill="url(#marble1)" stroke="#0f172a" strokeWidth="3" />
          <path d="M 90 35 Q 115 55 105 85 Q 98 65 90 35 Z" fill="#0369a1" opacity="0.8" />
          
          {/* Left marble */}
          <circle cx="55" cy="95" r="42" fill="url(#marble2)" stroke="#0f172a" strokeWidth="3" />
          <path d="M 40 70 Q 65 95 50 130 Q 42 105 40 70 Z" fill="#c2410c" opacity="0.8" />
          
          {/* Right marble */}
          <circle cx="115" cy="105" r="36" fill="url(#marble3)" stroke="#0f172a" strokeWidth="3" />
          <path d="M 105 85 Q 130 105 118 135 Q 110 115 105 85 Z" fill="#15803d" opacity="0.8" />
        </svg>
      );

    case 'dadu':
      // 3D Isometric dice matching worksheet #2
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          {/* Top Face */}
          <polygon points="80,25 135,50 80,75 25,50" fill="#f8fafc" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
          {/* Right Face */}
          <polygon points="135,50 135,115 80,140 80,75" fill="#e2e8f0" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
          {/* Left Face */}
          <polygon points="25,50 80,75 80,140 25,115" fill="#cbd5e1" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />

          {/* Top Face dots (6 dots) */}
          <circle cx="55" cy="46" r="4" fill="#ef4444" />
          <circle cx="70" cy="40" r="4" fill="#ef4444" />
          <circle cx="85" cy="34" r="4" fill="#ef4444" />
          <circle cx="75" cy="62" r="4" fill="#ef4444" />
          <circle cx="90" cy="56" r="4" fill="#ef4444" />
          <circle cx="105" cy="50" r="4" fill="#ef4444" />

          {/* Right face dots (3 dots) */}
          <circle cx="118" cy="72" r="4" fill="#0f172a" />
          <circle cx="108" cy="95" r="4" fill="#0f172a" />
          <circle cx="98" cy="118" r="4" fill="#0f172a" />

          {/* Left face dots (5 dots) */}
          <circle cx="45" cy="68" r="4" fill="#0f172a" />
          <circle cx="62" cy="76" r="4" fill="#0f172a" />
          <circle cx="53" cy="95" r="4" fill="#0f172a" />
          <circle cx="42" cy="108" r="4" fill="#0f172a" />
          <circle cx="62" cy="118" r="4" fill="#0f172a" />
        </svg>
      );

    case 'labu':
      // Pumpkin matching worksheet #3
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          {/* Stem */}
          <path d="M 76 42 Q 78 20 92 18 Q 88 32 84 42 Z" fill="#65a30d" stroke="#1e293b" strokeWidth="2.5" />
          {/* Back lobes */}
          <ellipse cx="50" cy="92" rx="36" ry="48" fill="#f59e0b" stroke="#1e293b" strokeWidth="3" />
          <ellipse cx="110" cy="92" rx="36" ry="48" fill="#f59e0b" stroke="#1e293b" strokeWidth="3" />
          {/* Outer ridges */}
          <ellipse cx="32" cy="95" rx="24" ry="40" fill="#d97706" stroke="#1e293b" strokeWidth="3" />
          <ellipse cx="128" cy="95" rx="24" ry="40" fill="#d97706" stroke="#1e293b" strokeWidth="3" />
          {/* Front central lobe */}
          <ellipse cx="80" cy="95" rx="32" ry="50" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" />
        </svg>
      );

    case 'lobak':
      // Carrot matching worksheet #4
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          {/* Leaves */}
          <path d="M 125 45 Q 148 20 152 14 Q 138 30 130 40 Z" fill="#22c55e" stroke="#1e293b" strokeWidth="2" />
          <path d="M 125 42 Q 135 15 142 8 Q 130 24 124 38 Z" fill="#16a34a" stroke="#1e293b" strokeWidth="2" />
          <path d="M 120 45 Q 118 18 122 10 Q 118 28 116 42 Z" fill="#15803d" stroke="#1e293b" strokeWidth="2" />
          {/* Carrot Body */}
          <path d="M 124 44 Q 120 54 85 85 Q 40 120 15 145 Q 22 135 70 80 Q 105 45 124 44 Z" fill="#f97316" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
          {/* Grooves */}
          <path d="M 105 60 Q 98 62 102 68" stroke="#ea580c" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M 80 82 Q 74 86 78 90" stroke="#ea580c" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M 52 108 Q 46 112 50 115" stroke="#ea580c" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    case 'cawan':
      // Cup matching worksheet #5
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          {/* Handle */}
          <path d="M 45 60 C 15 65 15 110 48 112" fill="none" stroke="#1e293b" strokeWidth="12" strokeLinecap="round" />
          <path d="M 45 60 C 15 65 15 110 48 112" fill="none" stroke="#67e8f9" strokeWidth="7" strokeLinecap="round" />
          {/* Saucer */}
          <ellipse cx="90" cy="138" rx="55" ry="12" fill="#e0f2fe" stroke="#1e293b" strokeWidth="3" />
          {/* Cup Body */}
          <path d="M 42 55 L 56 125 C 58 132 122 132 124 125 L 138 55 Z" fill="#06b6d4" stroke="#1e293b" strokeWidth="3" />
          {/* Cup Rim */}
          <ellipse cx="90" cy="55" rx="48" ry="14" fill="#a5f3fc" stroke="#1e293b" strokeWidth="3" />
          {/* Coffee inside */}
          <ellipse cx="90" cy="56" rx="42" ry="10" fill="#78350f" />
        </svg>
      );

    case 'katil':
      // Bed matching worksheet #6
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          {/* Headboard posts */}
          <rect x="115" y="25" width="8" height="60" rx="3" fill="#b45309" stroke="#1e293b" strokeWidth="2" />
          <rect x="142" y="30" width="8" height="55" rx="3" fill="#b45309" stroke="#1e293b" strokeWidth="2" />
          <path d="M 115 35 Q 130 25 145 38" stroke="#1e293b" strokeWidth="4" fill="#d97706" />
          {/* Pillow */}
          <ellipse cx="120" cy="75" rx="16" ry="10" fill="#f8fafc" stroke="#1e293b" strokeWidth="2.5" />
          {/* Mattress & Blanket */}
          <polygon points="110,75 140,80 80,140 25,125" fill="#f472b6" stroke="#1e293b" strokeWidth="3" />
          {/* Blanket Drape */}
          <path d="M 25 125 Q 50 145 80 140 L 80 152 Q 50 156 25 138 Z" fill="#db2777" stroke="#1e293b" strokeWidth="2.5" />
          <path d="M 80 140 Q 110 110 140 80 L 140 92 Q 110 122 80 152 Z" fill="#be185d" stroke="#1e293b" strokeWidth="2.5" />
        </svg>
      );

    case 'baju':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          <path d="M 50 35 L 70 48 Q 80 52 90 48 L 110 35 L 138 60 L 120 78 L 112 70 L 112 135 L 48 135 L 48 70 L 40 78 L 22 60 Z" fill="#3b82f6" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
          <circle cx="80" cy="70" r="4" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
          <circle cx="80" cy="92" r="4" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
          <circle cx="80" cy="114" r="4" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
          <path d="M 68 46 Q 80 58 92 46" fill="#60a5fa" stroke="#1e293b" strokeWidth="2" />
        </svg>
      );

    case 'bola':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          <circle cx="80" cy="80" r="55" fill="#ffffff" stroke="#1e293b" strokeWidth="4" />
          {/* Pentagons & seams */}
          <polygon points="80,60 95,72 89,90 71,90 65,72" fill="#1e293b" />
          <line x1="80" y1="60" x2="80" y2="35" stroke="#1e293b" strokeWidth="3" />
          <line x1="95" y1="72" x2="118" y2="62" stroke="#1e293b" strokeWidth="3" />
          <line x1="89" y1="90" x2="108" y2="112" stroke="#1e293b" strokeWidth="3" />
          <line x1="71" y1="90" x2="52" y2="112" stroke="#1e293b" strokeWidth="3" />
          <line x1="65" y1="72" x2="42" y2="62" stroke="#1e293b" strokeWidth="3" />
        </svg>
      );

    case 'buku':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          <path d="M 80 48 Q 50 35 22 42 L 22 120 Q 50 114 80 126 Q 110 114 138 120 L 138 42 Q 110 35 80 48 Z" fill="#6366f1" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
          <path d="M 80 50 L 80 126" stroke="#1e293b" strokeWidth="3" />
          {/* Pages */}
          <path d="M 76 52 Q 52 42 26 48 L 26 116 Q 52 110 76 122 Z" fill="#f8fafc" />
          <path d="M 84 52 Q 108 42 134 48 L 134 116 Q 108 110 84 122 Z" fill="#f8fafc" />
          <line x1="35" y1="65" x2="68" y2="62" stroke="#94a3b8" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="35" y1="80" x2="68" y2="77" stroke="#94a3b8" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="92" y1="62" x2="125" y2="65" stroke="#94a3b8" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="92" y1="77" x2="125" y2="80" stroke="#94a3b8" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );

    case 'gigi':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          <path d="M 45 45 C 30 55 35 85 45 105 C 52 120 54 138 60 138 C 68 138 72 108 80 108 C 88 108 92 138 100 138 C 106 138 108 120 115 105 C 125 85 130 55 115 45 C 100 35 88 45 80 45 C 72 45 60 35 45 45 Z" fill="#ffffff" stroke="#1e293b" strokeWidth="4" strokeLinejoin="round" />
          {/* Cheerful sparkles */}
          <path d="M 60 65 Q 68 65 68 58 Q 68 65 76 65 Q 68 65 68 72 Q 68 65 60 65 Z" fill="#38bdf8" />
          <path d="M 98 62 Q 104 62 104 56 Q 104 62 110 62 Q 104 62 104 68 Q 104 62 98 62 Z" fill="#38bdf8" />
        </svg>
      );

    case 'kaki':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          <path d="M 52 25 L 52 95 C 52 115 35 125 45 135 C 55 145 95 142 115 132 C 125 125 125 112 112 105 L 90 95 L 90 25 Z" fill="#fde047" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
          {/* Toes */}
          <ellipse cx="112" cy="116" rx="6" ry="5" fill="#facc15" stroke="#1e293b" strokeWidth="2" />
        </svg>
      );

    case 'mata':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          <path d="M 25 80 Q 80 30 135 80 Q 80 130 25 80 Z" fill="#ffffff" stroke="#1e293b" strokeWidth="4" strokeLinejoin="round" />
          <circle cx="80" cy="80" r="26" fill="#0284c7" stroke="#1e293b" strokeWidth="2.5" />
          <circle cx="80" cy="80" r="14" fill="#0f172a" />
          <circle cx="73" cy="73" r="5" fill="#ffffff" />
        </svg>
      );

    case 'roti':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          {/* Toast bread slice */}
          <path d="M 40 45 C 40 32 60 25 80 25 C 100 25 120 32 120 45 C 128 58 125 115 122 130 C 120 138 40 138 38 130 C 35 115 32 58 40 45 Z" fill="#fed7aa" stroke="#78350f" strokeWidth="4" />
          {/* Crust edge */}
          <path d="M 46 50 C 46 40 62 34 80 34 C 98 34 114 40 114 50 C 120 62 118 112 116 124 C 114 130 46 130 44 124 C 42 112 40 62 46 50 Z" fill="#ffedd5" />
          {/* Butter slab */}
          <rect x="68" y="72" width="24" height="20" rx="4" fill="#facc15" stroke="#ca8a04" strokeWidth="2" />
        </svg>
      );

    case 'sudu':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          {/* Handle */}
          <path d="M 125 130 L 75 75" stroke="#94a3b8" strokeWidth="12" strokeLinecap="round" />
          <path d="M 125 130 L 75 75" stroke="#cbd5e1" strokeWidth="8" strokeLinecap="round" />
          {/* Spoon head */}
          <ellipse cx="50" cy="50" rx="30" ry="20" transform="rotate(-45 50 50)" fill="#e2e8f0" stroke="#64748b" strokeWidth="3" />
          <ellipse cx="48" cy="48" rx="22" ry="14" transform="rotate(-45 48 48)" fill="#f8fafc" />
        </svg>
      );

    case 'topi':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          {/* Visor */}
          <path d="M 85 92 Q 138 90 148 105 Q 120 118 70 108 Z" fill="#9333ea" stroke="#1e293b" strokeWidth="3" />
          {/* Dome */}
          <path d="M 32 105 C 32 55 60 40 92 48 C 105 52 112 65 115 102 Z" fill="#a855f7" stroke="#1e293b" strokeWidth="3" />
          {/* Top button */}
          <circle cx="82" cy="46" r="6" fill="#facc15" stroke="#1e293b" strokeWidth="2" />
        </svg>
      );

    case 'kuda':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          {/* Mane and head */}
          <path d="M 50 135 L 55 90 L 70 65 L 65 42 L 80 40 L 95 60 L 125 72 L 122 95 L 98 88 L 105 135 Z" fill="#b45309" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
          {/* Ear */}
          <polygon points="70,40 75,20 85,38" fill="#d97706" stroke="#1e293b" strokeWidth="2.5" />
          {/* Eye */}
          <circle cx="95" cy="68" r="4" fill="#0f172a" />
          <circle cx="94" cy="67" r="1.5" fill="#ffffff" />
          {/* Mane details */}
          <path d="M 60 70 Q 50 85 62 95" stroke="#78350f" strokeWidth="3" />
        </svg>
      );

    case 'pasu':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          {/* Flower blooming on top */}
          <circle cx="80" cy="40" r="12" fill="#ef4444" stroke="#1e293b" strokeWidth="2" />
          <circle cx="80" cy="40" r="5" fill="#facc15" />
          <path d="M 80 52 L 80 75" stroke="#15803d" strokeWidth="4" />
          {/* Leaves */}
          <path d="M 80 62 Q 95 56 100 64 Q 90 70 80 65" fill="#22c55e" stroke="#1e293b" strokeWidth="2" />
          {/* Pot Rim */}
          <ellipse cx="80" cy="78" rx="36" ry="8" fill="#ea580c" stroke="#1e293b" strokeWidth="3" />
          {/* Pot Body */}
          <path d="M 48 82 L 56 132 C 58 138 102 138 104 132 L 112 82 Z" fill="#c2410c" stroke="#1e293b" strokeWidth="3" />
        </svg>
      );

    case 'feri':
      return (
        <svg width={size} height={size} viewBox="0 0 160 160" className={className} fill="none">
          {/* Water waves */}
          <path d="M 15 135 Q 40 142 65 135 Q 90 128 115 135 Q 140 142 155 135" stroke="#0284c7" strokeWidth="4" strokeLinecap="round" />
          {/* Hull */}
          <polygon points="25,125 45,95 125,95 140,125" fill="#ef4444" stroke="#1e293b" strokeWidth="3" />
          {/* Cabin */}
          <rect x="52" y="65" width="60" height="30" fill="#ffffff" stroke="#1e293b" strokeWidth="3" />
          {/* Windows */}
          <rect x="58" y="72" width="10" height="10" fill="#38bdf8" stroke="#1e293b" strokeWidth="1.5" />
          <rect x="76" y="72" width="10" height="10" fill="#38bdf8" stroke="#1e293b" strokeWidth="1.5" />
          <rect x="94" y="72" width="10" height="10" fill="#38bdf8" stroke="#1e293b" strokeWidth="1.5" />
          {/* Chimney */}
          <rect x="75" y="45" width="12" height="20" fill="#eab308" stroke="#1e293b" strokeWidth="2" />
        </svg>
      );

    default:
      return (
        <div className={`flex items-center justify-center rounded-2xl bg-sky-100 text-sky-700 font-bold ${className}`} style={{ width: size, height: size }}>
          {type}
        </div>
      );
  }
};
