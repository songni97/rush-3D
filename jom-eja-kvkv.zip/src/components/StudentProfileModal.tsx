import React, { useState } from 'react';
import { Student } from '../types';
import { getStudents, saveStudents, setActiveStudentId } from '../utils/storage';
import { X, UserPlus, Star, Award, Check } from 'lucide-react';
import { playSound } from '../utils/speech';

interface Props {
  activeStudent: Student;
  onClose: () => void;
  onStudentChanged: (student: Student) => void;
}

const AVATAR_OPTIONS = ['👦🏻', '👧🏻', '👦🏽', '👧🏽', '👦🏾', '👧🏾', '🦁', '🐱', '🐼', '🦊', '🐸', '🌟'];

export const StudentProfileModal: React.FC<Props> = ({
  activeStudent,
  onClose,
  onStudentChanged,
}) => {
  const [students, setStudents] = useState<Student[]>(getStudents());
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newClass, setNewClass] = useState('2 Cemerlang');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATAR_OPTIONS[0]);

  const handleSelectStudent = (student: Student) => {
    playSound('pop');
    setActiveStudentId(student.id);
    onStudentChanged(student);
    onClose();
  };

  const handleAddStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const newStudent: Student = {
      id: 'm-' + Date.now().toString().slice(-4),
      name: newName.trim(),
      className: newClass.trim() || '2 Cemerlang',
      avatar: selectedAvatar,
      stars: 0,
      totalScore: 0,
      badges: ['Bintang Pertama'],
      lastActive: new Date().toISOString(),
    };

    const updated = [...students, newStudent];
    saveStudents(updated);
    setStudents(updated);
    setActiveStudentId(newStudent.id);
    onStudentChanged(newStudent);
    playSound('correct');
    setShowAddForm(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 font-century">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border-2 border-sky-300 overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-sky-600 to-indigo-600 text-white p-5 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold">Pilih Profil Murid</h3>
            <p className="text-xs text-sky-100">
              Setiap murid mempunyai rekod markah dan bintang tersendiri.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 max-h-[75vh] overflow-y-auto">
          {!showAddForm ? (
            <>
              {/* Existing Student List */}
              <div className="space-y-2.5">
                {students.map((student) => {
                  const isActive = student.id === activeStudent.id;
                  return (
                    <div
                      key={student.id}
                      onClick={() => handleSelectStudent(student)}
                      className={`p-3.5 rounded-2xl border-2 transition cursor-pointer flex items-center justify-between ${
                        isActive
                          ? 'border-sky-500 bg-sky-50 shadow-md ring-2 ring-sky-200'
                          : 'border-slate-200 hover:border-sky-300 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-3xl p-1.5 bg-white rounded-xl shadow-xs border border-slate-100">
                          {student.avatar}
                        </span>
                        <div>
                          <p className="text-sm font-bold text-slate-900 leading-tight">
                            {student.name}
                          </p>
                          <p className="text-xs text-slate-500 font-medium">
                            {student.className}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1 bg-amber-100 text-amber-900 px-2.5 py-1 rounded-xl text-xs font-bold border border-amber-300">
                          <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-600" />
                          <span>{student.stars}</span>
                        </div>
                        {isActive && (
                          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-sky-600 text-white">
                            <Check className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Add New Student Button */}
              <button
                onClick={() => setShowAddForm(true)}
                className="mt-4 w-full py-3 rounded-2xl border-2 border-dashed border-sky-400 text-sky-700 hover:bg-sky-50 font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                <span>Daftar Murid Baharu</span>
              </button>
            </>
          ) : (
            /* Add Student Form */
            <form onSubmit={handleAddStudent} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Nama Murid:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Muhammad Danish bin Kamal"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Kelas Pemulihan / Aliran:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: 2 Cemerlang"
                  value={newClass}
                  onChange={(e) => setNewClass(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                  Pilih Ikon Avatar Murid:
                </label>
                <div className="grid grid-cols-6 gap-2">
                  {AVATAR_OPTIONS.map((av) => (
                    <button
                      type="button"
                      key={av}
                      onClick={() => setSelectedAvatar(av)}
                      className={`h-10 text-xl rounded-xl border-2 flex items-center justify-center transition cursor-pointer ${
                        selectedAvatar === av
                          ? 'border-sky-500 bg-sky-100 shadow-sm'
                          : 'border-slate-200 bg-white hover:bg-slate-50'
                      }`}
                    >
                      {av}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-50 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  Simpan Murid
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
