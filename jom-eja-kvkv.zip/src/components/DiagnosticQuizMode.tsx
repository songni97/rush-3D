import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { WordItem, Student } from '../types';
import { ALL_WORDS } from '../data/kvkvData';
import { WordIllustration } from './WordIllustration';
import { playSound, sebutPerkataan, beriPujianRawak, beriBimbinganRawak } from '../utils/speech';
import { recordAttempt } from '../utils/storage';
import { Volume2, CheckCircle2, XCircle, RotateCcw, ArrowRight, Award, Trophy, Star } from 'lucide-react';

interface Props {
  activeStudent: Student;
  soundEnabled: boolean;
  onStudentUpdated: () => void;
}

export const DiagnosticQuizMode: React.FC<Props> = ({
  activeStudent,
  soundEnabled,
  onStudentUpdated,
}) => {
  const [quizQuestions, setQuizQuestions] = useState<WordItem[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [quizHistory, setQuizHistory] = useState<Array<{ word: WordItem; chosen: string; isCorrect: boolean }>>([]);

  const initQuiz = () => {
    // Select 10 randomized words
    const shuffled = [...ALL_WORDS].sort(() => Math.random() - 0.5).slice(0, 10);
    setQuizQuestions(shuffled);
    setCurrentIdx(0);
    setSelectedAnswer(null);
    setIsAnswered(false);
    setScore(0);
    setIsFinished(false);
    setQuizHistory([]);
  };

  useEffect(() => {
    initQuiz();
  }, []);

  if (quizQuestions.length === 0) return null;

  const currentQ = quizQuestions[currentIdx];

  const handleSelectOption = (chosen: string) => {
    if (isAnswered) return;
    setSelectedAnswer(chosen);
    setIsAnswered(true);

    const isCorrect = chosen.toLowerCase() === currentQ.correctAnswer.toLowerCase();

    // Record attempt
    recordAttempt({
      studentId: activeStudent.id,
      studentName: activeStudent.name,
      wordId: currentQ.id,
      word: currentQ.word,
      targetSyllable: currentQ.correctAnswer,
      chosenSyllable: chosen,
      isCorrect,
      timeSpentSeconds: 6,
      attemptsCount: 1,
      mode: 'kuiz',
    });

    setQuizHistory((prev) => [...prev, { word: currentQ, chosen, isCorrect }]);

    if (isCorrect) {
      setScore((prev) => prev + 1);
      playSound('correct');
      if (soundEnabled) {
        sebutPerkataan(chosen, 0.9);
        setTimeout(() => beriPujianRawak(), 400);
      }
      onStudentUpdated();
    } else {
      playSound('wrong');
      if (soundEnabled) {
        sebutPerkataan(chosen, 0.9);
        setTimeout(() => beriBimbinganRawak(), 400);
      }
    }
  };

  const handleNextQuestion = () => {
    playSound('pop');
    if (currentIdx < quizQuestions.length - 1) {
      setCurrentIdx((prev) => prev + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
    } else {
      setIsFinished(true);
      playSound('fanfare');
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.5 },
      });
    }
  };

  // Completion Screen
  if (isFinished) {
    const percentage = Math.round((score / quizQuestions.length) * 100);
    let tahap = 'TP1';
    let ulasan = 'Memerlukan bimbingan rapi daripada guru bagi mengecam suku kata asas.';
    if (percentage >= 90) {
      tahap = 'TP6';
      ulasan = 'Cemerlang! Penguasaan membaca dan mencantum suku kata KVKV pada tahap optimum.';
    } else if (percentage >= 80) {
      tahap = 'TP5';
      ulasan = 'Sangat baik. Murid berupaya membina perkataan KVKV dengan yakin dan tepat.';
    } else if (percentage >= 70) {
      tahap = 'TP4';
      ulasan = 'Baik. Murid menguasai kemahiran KVKV dengan sedikit kesilapan kecil.';
    } else if (percentage >= 50) {
      tahap = 'TP3';
      ulasan = 'Mencapai tahap minimum. Perlu teruskan latihan pengukuhan suku kata terbuka.';
    } else if (percentage >= 30) {
      tahap = 'TP2';
      ulasan = 'Perlu bimbingan intervensi vokal dan konsonan secara latih tubi berfokus.';
    }

    return (
      <div className="max-w-2xl mx-auto px-4 py-8 font-century">
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border-2 border-sky-200 text-center">
          <div className="inline-flex p-4 bg-amber-100 rounded-3xl mb-4 text-amber-600 shadow-sm">
            <Trophy className="w-16 h-16" />
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            Keputusan Kuiz Diagnostik PBD
          </h2>
          <p className="text-sm font-semibold text-slate-500 mt-1">
            Murid: {activeStudent.name} ({activeStudent.className})
          </p>

          {/* Score Circle */}
          <div className="my-6 inline-flex flex-col items-center justify-center p-6 rounded-full bg-gradient-to-tr from-sky-500 to-indigo-600 text-white w-36 h-36 shadow-lg border-4 border-white">
            <span className="text-4xl font-black">{score} / 10</span>
            <span className="text-xs font-bold text-sky-100">{percentage}% Ketepatan</span>
          </div>

          {/* PBD Tahap Penguasaan Card */}
          <div className="bg-sky-50 rounded-2xl p-4 border border-sky-200 text-left mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-sky-900 uppercase">Tahap Penguasaan PBD:</span>
              <span className="bg-amber-400 text-amber-950 font-black px-2.5 py-0.5 rounded-lg text-sm">
                {tahap}
              </span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-medium">
              <strong>Ulasan Guru Pemulihan:</strong> {ulasan}
            </p>
          </div>

          {/* Breakdown of results */}
          <div className="text-left mb-6">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
              Perincian 10 Soalan:
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {quizHistory.map((item, i) => (
                <div
                  key={i}
                  className={`p-2.5 rounded-xl border text-center ${
                    item.isCorrect
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                      : 'bg-rose-50 border-rose-200 text-rose-800'
                  }`}
                >
                  <p className="text-xs font-bold">{item.word.word}</p>
                  <p className="text-[10px] mt-0.5 font-semibold">
                    {item.isCorrect ? '✓ Betul' : `✗ (${item.chosen})`}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-center gap-3">
            <button
              onClick={initQuiz}
              className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-6 py-2.5 rounded-xl text-sm shadow-md transition cursor-pointer flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Ambil Kuiz Semula</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Active Question Card
  return (
    <div className="max-w-2xl mx-auto px-4 py-6 font-century">
      {/* Quiz Progress header */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border-2 border-sky-200 mb-6 flex items-center justify-between">
        <div>
          <span className="text-xs font-bold text-sky-700 uppercase tracking-wider">
            Kuiz Diagnostik KVKV
          </span>
          <h3 className="text-lg font-bold text-slate-800">
            Soalan {currentIdx + 1} daripada {quizQuestions.length}
          </h3>
        </div>
        <div className="flex items-center gap-2 bg-amber-100 text-amber-900 px-3 py-1.5 rounded-xl font-bold text-xs border border-amber-200">
          <Star className="w-4 h-4 fill-amber-500 text-amber-600" />
          <span>Markah: {score}</span>
        </div>
      </div>

      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-md border-3 border-slate-200 relative text-center">
        {/* Audio helper */}
        <button
          onClick={() => {
            if (soundEnabled) {
              sebutPerkataan(currentQ.word, 0.85);
            }
          }}
          className="absolute top-4 right-4 flex items-center gap-1.5 bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer"
        >
          <Volume2 className="w-4 h-4" />
          <span>Dengar Petunjuk</span>
        </button>

        {/* Question Prompt */}
        <p className="text-base font-bold text-slate-800 mt-2 mb-4">
          Apakah suku kata yang betul bagi melengkapkan perkataan ini?
        </p>

        {/* Center Illustration */}
        <div className="inline-block p-4 rounded-3xl bg-slate-50 border-2 border-slate-100 shadow-inner mb-4">
          <WordIllustration type={currentQ.svgType} size={150} />
        </div>

        {/* Word Display with Slot */}
        <div className="my-4 text-3xl font-black text-slate-900 tracking-wider flex items-center justify-center gap-2">
          {currentQ.missingPosition === 2 ? (
            <>
              <span>{currentQ.prefixDisplay}</span>
              <span
                className={`min-w-[64px] px-3 py-1 rounded-xl border-2 ${
                  isAnswered
                    ? selectedAnswer === currentQ.correctAnswer
                      ? 'bg-emerald-600 text-white border-emerald-700'
                      : 'bg-rose-600 text-white border-rose-700'
                    : 'bg-slate-100 text-slate-400 border-dashed border-slate-300'
                }`}
              >
                {selectedAnswer || '_ _'}
              </span>
            </>
          ) : (
            <>
              <span
                className={`min-w-[64px] px-3 py-1 rounded-xl border-2 ${
                  isAnswered
                    ? selectedAnswer === currentQ.correctAnswer
                      ? 'bg-emerald-600 text-white border-emerald-700'
                      : 'bg-rose-600 text-white border-rose-700'
                    : 'bg-slate-100 text-slate-400 border-dashed border-slate-300'
                }`}
              >
                {selectedAnswer || '_ _'}
              </span>
              <span>{currentQ.suffixDisplay}</span>
            </>
          )}
        </div>

        {/* Option choices */}
        <div className="grid grid-cols-3 gap-3 max-w-sm mx-auto mt-6">
          {currentQ.options.map((opt) => {
            const isSelected = selectedAnswer === opt;
            const isTarget = opt === currentQ.correctAnswer;

            let btnStyle = 'bg-slate-50 hover:bg-sky-50 text-slate-800 border-slate-200 hover:border-sky-400';
            if (isAnswered) {
              if (isTarget) {
                btnStyle = 'bg-emerald-500 text-white border-emerald-600 ring-4 ring-emerald-200';
              } else if (isSelected) {
                btnStyle = 'bg-rose-500 text-white border-rose-600';
              } else {
                btnStyle = 'bg-slate-100 text-slate-400 border-slate-200 opacity-60';
              }
            }

            return (
              <button
                key={opt}
                disabled={isAnswered}
                onClick={() => handleSelectOption(opt)}
                className={`h-16 rounded-2xl border-2 font-black text-2xl transition cursor-pointer shadow-sm active:scale-95 ${btnStyle}`}
              >
                {opt}
              </button>
            );
          })}
        </div>

        {/* Feedback & Next Button */}
        {isAnswered && (
          <div className="mt-6 pt-5 border-t border-slate-100 flex items-center justify-between animate-in fade-in duration-200">
            <div className="text-left">
              {selectedAnswer === currentQ.correctAnswer ? (
                <span className="text-emerald-700 font-bold flex items-center gap-1.5 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Jawapan adik betul! ({currentQ.word})
                </span>
              ) : (
                <span className="text-rose-600 font-bold flex items-center gap-1.5 text-sm">
                  <XCircle className="w-4 h-4 text-rose-500" />
                  Kurang tepat. Jawapannya ialah "{currentQ.correctAnswer}".
                </span>
              )}
            </div>

            <button
              onClick={handleNextQuestion}
              className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-5 py-2.5 rounded-xl text-sm shadow-md transition flex items-center gap-2 cursor-pointer"
            >
              <span>{currentIdx < quizQuestions.length - 1 ? 'Soalan Seterusnya' : 'Lihat Keputusan'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
