import React from 'react';
import { Student, GameMode } from '../types';
import { PWAInstallButton } from './PWAInstallButton';
import { Volume2, VolumeX, BarChart3, UserCheck, Star, Sparkles, BookOpen, Puzzle, HelpCircle, Layers } from 'lucide-react';

interface Props {
  currentMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  activeStudent: Student;
  onOpenStudentModal: () => void;
  onOpenTeacherDashboard: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Header: React.FC<Props> = ({
  currentMode,
  onSelectMode,
  activeStudent,
  onOpenStudentModal,
  onOpenTeacherDashboard,
  soundEnabled,
  onToggleSound,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-2 border-sky-100 shadow-xs font-century">
      {/* Top Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 sm:px-6 flex flex-wrap items-center justify-between gap-3">
        {/* Logo and Brand */}
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-tr from-sky-600 via-sky-500 to-amber-400 text-white font-black text-xl shadow-md border-2 border-white">
            KV
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-slate-900 leading-none">
                Bijak Suku Kata KVKV
              </h1>
              <span className="hidden sm:inline-flex items-center rounded-md bg-amber-100 px-2 py-0.5 text-xs font-bold text-amber-900 border border-amber-300">
                Pemulihan Khas
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Program Pemulihan Khas Kementerian Pendidikan Malaysia
            </p>
          </div>
        </div>

        {/* Right Action Tools: Student Badge, PWA Install, Audio, Teacher Dashboard */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Active Student Pill */}
          <button
            onClick={onOpenStudentModal}
            className="flex items-center gap-2 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 px-3 py-1.5 transition cursor-pointer text-left"
            title="Tukar profil murid atau tambah murid baru"
          >
            <span className="text-xl leading-none">{activeStudent.avatar}</span>
            <div className="hidden sm:block">
              <p className="text-xs font-bold text-sky-950 truncate max-w-[130px] leading-tight">
                {activeStudent.name.split(' ')[0]} {activeStudent.name.split(' ')[1] || ''}
              </p>
              <p className="text-[10px] text-sky-700 font-semibold">{activeStudent.className}</p>
            </div>
            <div className="flex items-center gap-1 bg-amber-400 text-amber-950 px-2 py-0.5 rounded-full text-xs font-bold ml-1 shadow-xs">
              <Star className="w-3 h-3 fill-amber-950" />
              <span>{activeStudent.stars}</span>
            </div>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className={`p-2 rounded-xl border transition cursor-pointer ${
              soundEnabled
                ? 'bg-sky-500 text-white border-sky-600 hover:bg-sky-600'
                : 'bg-slate-100 text-slate-400 border-slate-200 hover:bg-slate-200'
            }`}
            title={soundEnabled ? 'Matikan Suara' : 'Hidupkan Suara'}
            aria-label="Kawalan Suara"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Teacher Analytics Button */}
          <button
            onClick={onOpenTeacherDashboard}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 text-xs font-bold shadow-sm transition active:scale-95 cursor-pointer"
            title="Buka Dashboard Analitik dan Borang Transit PBD Guru"
          >
            <BarChart3 className="w-4 h-4" />
            <span className="hidden md:inline">Dashboard Guru</span>
          </button>

          {/* PWA Install Button */}
          <PWAInstallButton />
        </div>
      </div>

      {/* Navigation Modes Bar */}
      <div className="bg-sky-100/70 border-t border-sky-200/80 px-4 py-1.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between overflow-x-auto gap-2 no-scrollbar py-0.5">
          <div className="flex items-center gap-1.5 min-w-max">
            <button
              onClick={() => onSelectMode('lembaran')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                currentMode === 'lembaran'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-sky-50 border border-sky-200'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Lembaran Bergambar</span>
              <span className="text-[10px] bg-amber-400 text-slate-900 px-1.5 py-0.2 rounded font-extrabold">
                Buku
              </span>
            </button>

            <button
              onClick={() => onSelectMode('cantum')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                currentMode === 'cantum'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-sky-50 border border-sky-200'
              }`}
            >
              <Puzzle className="w-3.5 h-3.5" />
              <span>Cantum Suku Kata (KV + KV)</span>
            </button>

            <button
              onClick={() => onSelectMode('kuiz')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                currentMode === 'kuiz'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-sky-50 border border-sky-200'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Kuiz Diagnostik PBD</span>
            </button>

            <button
              onClick={() => onSelectMode('kad')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                currentMode === 'kad'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-sky-50 border border-sky-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Kad Imbasan Suara</span>
            </button>
          </div>

          <div className="hidden lg:flex items-center gap-2 text-xs font-semibold text-sky-900 bg-white/70 px-3 py-1 rounded-md border border-sky-200">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Petua: Tarik atau tekan suku kata untuk mengisi tempat kosong!</span>
          </div>
        </div>
      </div>
    </header>
  );
};
