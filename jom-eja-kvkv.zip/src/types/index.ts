export interface SukuKataOption {
  id: string;
  text: string;
  isCorrect?: boolean;
}

export interface WordItem {
  id: string;
  word: string; // e.g. "guli"
  syllable1: string; // e.g. "gu"
  syllable2: string; // e.g. "li"
  missingPosition: 1 | 2; // 1 for "_ _ bak", 2 for "gu _ _"
  prefixDisplay?: string; // e.g. "gu"
  suffixDisplay?: string; // e.g. "bak", "wan", "til"
  options: string[]; // e.g. ["la", "le", "li"]
  correctAnswer: string; // e.g. "li"
  category: 'KVKV' | 'KVKVK';
  meaning: string;
  svgType: string;
  themeColor: string;
}

export interface Student {
  id: string;
  name: string;
  className: string;
  avatar: string;
  stars: number;
  totalScore: number;
  badges: string[];
  lastActive: string;
}

export interface AttemptLog {
  id: string;
  studentId: string;
  studentName: string;
  wordId: string;
  word: string;
  targetSyllable: string;
  chosenSyllable: string;
  isCorrect: boolean;
  timeSpentSeconds: number;
  attemptsCount: number;
  mode: 'lembaran' | 'cantum' | 'kuiz';
  timestamp: string; // ISO string
}

export interface StudentStats {
  studentId: string;
  totalAttempts: number;
  correctAttempts: number;
  accuracyRate: number;
  masteredWords: string[];
  wordsNeedingPractice: string[];
  troubleSyllables: { syllable: string; wrongCount: number }[];
  pbdLevel: 1 | 2 | 3 | 4 | 5 | 6;
  pbdStatus: 'Belum Menguasai' | 'Sedang Menguasai' | 'Telah Menguasai';
  notes: string;
}

export type GameMode = 'lembaran' | 'cantum' | 'kuiz' | 'kad';
