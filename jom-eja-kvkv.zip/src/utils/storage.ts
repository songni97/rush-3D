import { Student, AttemptLog, StudentStats } from '../types';

const STORAGE_KEYS = {
  STUDENTS: 'kvkv_pemulihan_students',
  ACTIVE_STUDENT: 'kvkv_pemulihan_active_student_id',
  ATTEMPT_LOGS: 'kvkv_pemulihan_attempt_logs',
};

export const DEFAULT_STUDENTS: Student[] = [
  {
    id: 'm-001',
    name: 'Aiman Haziq bin Rosli',
    className: '2 Cemerlang',
    avatar: '👦🏻',
    stars: 38,
    totalScore: 420,
    badges: ['Bintang Pertama', 'Pakar Suku Kata', 'Rajin Berusaha'],
    lastActive: '2026-10-14T08:30:00Z',
  },
  {
    id: 'm-002',
    name: 'Nur Damia Insyirah binti Azman',
    className: '2 Amanah',
    avatar: '👧🏽',
    stars: 45,
    totalScore: 510,
    badges: ['Bintang Pertama', 'Pakar Suku Kata', 'Cekap Mengeja', 'Juara KVKV'],
    lastActive: '2026-10-14T08:45:00Z',
  },
  {
    id: 'm-003',
    name: 'Muhammad Danish Rayyan',
    className: '3 Arif',
    avatar: '👦🏽',
    stars: 22,
    totalScore: 260,
    badges: ['Bintang Pertama', 'Rajin Berusaha'],
    lastActive: '2026-10-13T10:15:00Z',
  },
  {
    id: 'm-004',
    name: 'Siti Aisyah Humaira',
    className: '2 Bakti',
    avatar: '👧🏻',
    stars: 52,
    totalScore: 590,
    badges: ['Bintang Pertama', 'Pakar Suku Kata', 'Cekap Mengeja', 'Juara KVKV', 'Mata Helang'],
    lastActive: '2026-10-14T09:10:00Z',
  },
  {
    id: 'm-005',
    name: 'Tan Chong Wei',
    className: '2 Cemerlang',
    avatar: '👦🏻',
    stars: 28,
    totalScore: 310,
    badges: ['Bintang Pertama', 'Rajin Berusaha'],
    lastActive: '2026-10-13T11:20:00Z',
  },
];

export const INITIAL_LOGS: AttemptLog[] = [
  // Aiman Haziq sample logs
  { id: 'log-1', studentId: 'm-001', studentName: 'Aiman Haziq bin Rosli', wordId: 'w-guli', word: 'guli', targetSyllable: 'li', chosenSyllable: 'li', isCorrect: true, timeSpentSeconds: 4, attemptsCount: 1, mode: 'lembaran', timestamp: '2026-10-14T08:15:00Z' },
  { id: 'log-2', studentId: 'm-001', studentName: 'Aiman Haziq bin Rosli', wordId: 'w-dadu', word: 'dadu', targetSyllable: 'du', chosenSyllable: 'da', isCorrect: false, timeSpentSeconds: 7, attemptsCount: 2, mode: 'lembaran', timestamp: '2026-10-14T08:16:00Z' },
  { id: 'log-3', studentId: 'm-001', studentName: 'Aiman Haziq bin Rosli', wordId: 'w-dadu', word: 'dadu', targetSyllable: 'du', chosenSyllable: 'du', isCorrect: true, timeSpentSeconds: 3, attemptsCount: 2, mode: 'lembaran', timestamp: '2026-10-14T08:17:00Z' },
  { id: 'log-4', studentId: 'm-001', studentName: 'Aiman Haziq bin Rosli', wordId: 'w-labu', word: 'labu', targetSyllable: 'bu', chosenSyllable: 'bu', isCorrect: true, timeSpentSeconds: 5, attemptsCount: 1, mode: 'lembaran', timestamp: '2026-10-14T08:18:00Z' },
  { id: 'log-5', studentId: 'm-001', studentName: 'Aiman Haziq bin Rosli', wordId: 'w-lobak', word: 'lobak', targetSyllable: 'lo', chosenSyllable: 'lo', isCorrect: true, timeSpentSeconds: 4, attemptsCount: 1, mode: 'lembaran', timestamp: '2026-10-14T08:19:00Z' },
  { id: 'log-6', studentId: 'm-001', studentName: 'Aiman Haziq bin Rosli', wordId: 'w-baju', word: 'baju', targetSyllable: 'ju', chosenSyllable: 'ju', isCorrect: true, timeSpentSeconds: 3, attemptsCount: 1, mode: 'cantum', timestamp: '2026-10-14T08:25:00Z' },
  { id: 'log-7', studentId: 'm-001', studentName: 'Aiman Haziq bin Rosli', wordId: 'w-bola', word: 'bola', targetSyllable: 'la', chosenSyllable: 'li', isCorrect: false, timeSpentSeconds: 8, attemptsCount: 2, mode: 'cantum', timestamp: '2026-10-14T08:26:00Z' },

  // Nur Damia sample logs
  { id: 'log-8', studentId: 'm-002', studentName: 'Nur Damia Insyirah binti Azman', wordId: 'w-guli', word: 'guli', targetSyllable: 'li', chosenSyllable: 'li', isCorrect: true, timeSpentSeconds: 2, attemptsCount: 1, mode: 'lembaran', timestamp: '2026-10-14T08:35:00Z' },
  { id: 'log-9', studentId: 'm-002', studentName: 'Nur Damia Insyirah binti Azman', wordId: 'w-dadu', word: 'dadu', targetSyllable: 'du', chosenSyllable: 'du', isCorrect: true, timeSpentSeconds: 3, attemptsCount: 1, mode: 'lembaran', timestamp: '2026-10-14T08:36:00Z' },
  { id: 'log-10', studentId: 'm-002', studentName: 'Nur Damia Insyirah binti Azman', wordId: 'w-cawan', word: 'cawan', targetSyllable: 'ca', chosenSyllable: 'ca', isCorrect: true, timeSpentSeconds: 3, attemptsCount: 1, mode: 'lembaran', timestamp: '2026-10-14T08:37:00Z' },
  { id: 'log-11', studentId: 'm-002', studentName: 'Nur Damia Insyirah binti Azman', wordId: 'w-katil', word: 'katil', targetSyllable: 'ka', chosenSyllable: 'ka', isCorrect: true, timeSpentSeconds: 4, attemptsCount: 1, mode: 'lembaran', timestamp: '2026-10-14T08:38:00Z' },
  { id: 'log-12', studentId: 'm-002', studentName: 'Nur Damia Insyirah binti Azman', wordId: 'w-gigi', word: 'gigi', targetSyllable: 'gi', chosenSyllable: 'gi', isCorrect: true, timeSpentSeconds: 2, attemptsCount: 1, mode: 'kuiz', timestamp: '2026-10-14T08:42:00Z' },

  // Muhammad Danish sample logs (Needs intervention)
  { id: 'log-13', studentId: 'm-003', studentName: 'Muhammad Danish Rayyan', wordId: 'w-guli', word: 'guli', targetSyllable: 'li', chosenSyllable: 'la', isCorrect: false, timeSpentSeconds: 12, attemptsCount: 3, mode: 'lembaran', timestamp: '2026-10-13T10:05:00Z' },
  { id: 'log-14', studentId: 'm-003', studentName: 'Muhammad Danish Rayyan', wordId: 'w-dadu', word: 'dadu', targetSyllable: 'du', chosenSyllable: 'da', isCorrect: false, timeSpentSeconds: 15, attemptsCount: 3, mode: 'lembaran', timestamp: '2026-10-13T10:08:00Z' },
  { id: 'log-15', studentId: 'm-003', studentName: 'Muhammad Danish Rayyan', wordId: 'w-labu', word: 'labu', targetSyllable: 'bu', chosenSyllable: 'ba', isCorrect: false, timeSpentSeconds: 10, attemptsCount: 2, mode: 'lembaran', timestamp: '2026-10-13T10:12:00Z' },
  { id: 'log-16', studentId: 'm-003', studentName: 'Muhammad Danish Rayyan', wordId: 'w-baju', word: 'baju', targetSyllable: 'ju', chosenSyllable: 'ju', isCorrect: true, timeSpentSeconds: 8, attemptsCount: 1, mode: 'cantum', timestamp: '2026-10-13T10:14:00Z' },
];

export function getStudents(): Student[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.STUDENTS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(DEFAULT_STUDENTS));
      return DEFAULT_STUDENTS;
    }
    return JSON.parse(data);
  } catch {
    return DEFAULT_STUDENTS;
  }
}

export function saveStudents(students: Student[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  } catch {
    // ignore local storage errors
  }
}

export function getActiveStudentId(): string {
  try {
    const id = localStorage.getItem(STORAGE_KEYS.ACTIVE_STUDENT);
    if (id) return id;
    const students = getStudents();
    const defaultId = students[0]?.id || 'm-001';
    localStorage.setItem(STORAGE_KEYS.ACTIVE_STUDENT, defaultId);
    return defaultId;
  } catch {
    return 'm-001';
  }
}

export function setActiveStudentId(id: string) {
  try {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_STUDENT, id);
  } catch {
    // ignore
  }
}

export function getAttemptLogs(): AttemptLog[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ATTEMPT_LOGS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.ATTEMPT_LOGS, JSON.stringify(INITIAL_LOGS));
      return INITIAL_LOGS;
    }
    return JSON.parse(data);
  } catch {
    return INITIAL_LOGS;
  }
}

export function recordAttempt(log: Omit<AttemptLog, 'id' | 'timestamp'>) {
  try {
    const logs = getAttemptLogs();
    const newLog: AttemptLog = {
      ...log,
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toISOString(),
    };
    logs.unshift(newLog);
    // Keep last 500 logs
    const trimmed = logs.slice(0, 500);
    localStorage.setItem(STORAGE_KEYS.ATTEMPT_LOGS, JSON.stringify(trimmed));

    // Update student stars and scores if correct
    if (log.isCorrect) {
      const students = getStudents();
      const studentIndex = students.findIndex((s) => s.id === log.studentId);
      if (studentIndex !== -1) {
        students[studentIndex].stars += 1;
        students[studentIndex].totalScore += 10;
        students[studentIndex].lastActive = newLog.timestamp;

        // Check badge unlocks
        const student = students[studentIndex];
        if (student.stars >= 10 && !student.badges.includes('Bintang Pertama')) {
          student.badges.push('Bintang Pertama');
        }
        if (student.stars >= 30 && !student.badges.includes('Pakar Suku Kata')) {
          student.badges.push('Pakar Suku Kata');
        }
        if (student.stars >= 50 && !student.badges.includes('Juara KVKV')) {
          student.badges.push('Juara KVKV');
        }
        saveStudents(students);
      }
    }
    return newLog;
  } catch {
    return null;
  }
}

export function calculateStudentStats(studentId: string): StudentStats {
  const logs = getAttemptLogs().filter((l) => l.studentId === studentId);
  const totalAttempts = logs.length;
  const correctAttempts = logs.filter((l) => l.isCorrect).length;
  const accuracyRate = totalAttempts > 0 ? Math.round((correctAttempts / totalAttempts) * 100) : 0;

  // Track words
  const wordStatus: Record<string, { correct: number; wrong: number }> = {};
  const syllableErrors: Record<string, number> = {};

  logs.forEach((log) => {
    if (!wordStatus[log.word]) {
      wordStatus[log.word] = { correct: 0, wrong: 0 };
    }
    if (log.isCorrect) {
      wordStatus[log.word].correct += 1;
    } else {
      wordStatus[log.word].wrong += 1;
      syllableErrors[log.targetSyllable] = (syllableErrors[log.targetSyllable] || 0) + 1;
    }
  });

  const masteredWords = Object.keys(wordStatus).filter(
    (w) => wordStatus[w].correct >= 2 && wordStatus[w].wrong <= 1
  );
  const wordsNeedingPractice = Object.keys(wordStatus).filter(
    (w) => wordStatus[w].wrong > wordStatus[w].correct || wordStatus[w].wrong >= 2
  );

  const troubleSyllables = Object.keys(syllableErrors)
    .map((s) => ({ syllable: s, wrongCount: syllableErrors[s] }))
    .sort((a, b) => b.wrongCount - a.wrongCount);

  // KPM Remedial PBD Level Calculation (TP1 - TP6)
  let pbdLevel: 1 | 2 | 3 | 4 | 5 | 6 = 1;
  let pbdStatus: 'Belum Menguasai' | 'Sedang Menguasai' | 'Telah Menguasai' = 'Belum Menguasai';
  let notes = 'Perlu bimbingan intensif guru dalam membunyikan dan mengecam suku kata KVKV.';

  if (totalAttempts < 3) {
    pbdLevel = 1;
    pbdStatus = 'Belum Menguasai';
    notes = 'Ujian baru dimulakan. Perlu lebih banyak aktiviti pengukuhan.';
  } else if (accuracyRate < 50) {
    pbdLevel = 2;
    pbdStatus = 'Belum Menguasai';
    notes = 'Masih keliru dengan vokal (a, e, i, o, u) pada suku kata kedua. Perlu latih tubi sebutan.';
  } else if (accuracyRate < 70) {
    pbdLevel = 3;
    pbdStatus = 'Sedang Menguasai';
    notes = 'Boleh membaca suku kata asas dengan bimbingan minima guru.';
  } else if (accuracyRate < 85) {
    pbdLevel = 4;
    pbdStatus = 'Sedang Menguasai';
    notes = 'Menguasai kemahiran KVKV dengan lancar dan membuat sedikit kesilapan kecil.';
  } else if (accuracyRate < 95) {
    pbdLevel = 5;
    pbdStatus = 'Telah Menguasai';
    notes = 'Sangat baik. Boleh mencantum suku kata KVKV secara pantas dan tepat.';
  } else {
    pbdLevel = 6;
    pbdStatus = 'Telah Menguasai';
    notes = 'Cemerlang! Boleh dijadikan murid contoh dan pembimbing rakan sebaya.';
  }

  return {
    studentId,
    totalAttempts,
    correctAttempts,
    accuracyRate,
    masteredWords,
    wordsNeedingPractice,
    troubleSyllables,
    pbdLevel,
    pbdStatus,
    notes,
  };
}

export function exportBorangTransitCSV(students: Student[]): string {
  const headers = [
    'No',
    'Nama Murid',
    'Kelas',
    'Jumlah Bintang',
    'Peratus Ketepatan (%)',
    'Tahap Penguasaan (TP)',
    'Status PBD',
    'Perkataan Dikuasai',
    'Perlu Intervensi',
    'Catatan Guru Pemulihan',
  ];

  const rows = students.map((s, index) => {
    const stats = calculateStudentStats(s.id);
    return [
      index + 1,
      `"${s.name}"`,
      `"${s.className}"`,
      s.stars,
      `${stats.accuracyRate}%`,
      `TP${stats.pbdLevel}`,
      `"${stats.pbdStatus}"`,
      `"${stats.masteredWords.join(', ') || '-'}"`,
      `"${stats.wordsNeedingPractice.join(', ') || '-'}"`,
      `"${stats.notes}"`,
    ];
  });

  return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
}

export function resetAllData() {
  localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(DEFAULT_STUDENTS));
  localStorage.setItem(STORAGE_KEYS.ATTEMPT_LOGS, JSON.stringify(INITIAL_LOGS));
  localStorage.setItem(STORAGE_KEYS.ACTIVE_STUDENT, DEFAULT_STUDENTS[0].id);
}
