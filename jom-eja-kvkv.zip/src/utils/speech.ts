// Malaysian Malay Speech & Web Audio Sound System for Remedial Education

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

// Pleasant kid-friendly sound effects using Web Audio API (no external asset network dependency)
export function playSound(type: 'correct' | 'wrong' | 'pop' | 'fanfare' | 'star') {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    if (type === 'correct') {
      // Cheerful marimba chime (C5 -> E5 -> G5 -> C6)
      const notes = [523.25, 659.25, 783.99, 1046.50];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        gain.gain.setValueAtTime(0, now + idx * 0.08);
        gain.gain.linearRampToValueAtTime(0.25, now + idx * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.28);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.3);
      });
    } else if (type === 'wrong') {
      // Gentle encouraging boop (low soft tone, not harsh)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(260, now);
      osc.frequency.linearRampToValueAtTime(200, now + 0.25);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.26);
    } else if (type === 'pop') {
      // Soft click/pop on drag & drop or tap
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(450, now);
      osc.frequency.exponentialRampToValueAtTime(800, now + 0.06);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.07);
    } else if (type === 'star') {
      // Sparkle sound
      const notes = [659.25, 880, 1174.66, 1318.51];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.05);

        gain.gain.setValueAtTime(0.18, now + idx * 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.05 + 0.2);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.05);
        osc.stop(now + idx * 0.05 + 0.22);
      });
    } else if (type === 'fanfare') {
      // Victory fanfare
      const melody = [
        { f: 523.25, d: 0.12 },
        { f: 659.25, d: 0.12 },
        { f: 783.99, d: 0.12 },
        { f: 1046.50, d: 0.35 },
      ];
      let offset = 0;
      melody.forEach((note) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(note.f, now + offset);

        gain.gain.setValueAtTime(0.25, now + offset);
        gain.gain.exponentialRampToValueAtTime(0.001, now + offset + note.d);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + offset);
        osc.stop(now + offset + note.d + 0.05);
        offset += note.d * 0.9;
      });
    }
  } catch {
    // AudioContext might be blocked until user gesture, safely ignore
  }
}

// Speak text using Web Speech API in authentic Malaysian Malay (ms-MY)
export function sebutPerkataan(text: string, rate: number = 0.85) {
  if (!('speechSynthesis' in window)) return;

  try {
    window.speechSynthesis.cancel(); // Cancel any ongoing speech
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = rate; // Gentle pace suitable for remedial children
    utterance.pitch = 1.1; // Friendly warm pitch

    // Find best Malay voice if available
    const voices = window.speechSynthesis.getVoices();
    const malayVoice = voices.find(
      (v) => v.lang.toLowerCase() === 'ms-my' || v.lang.toLowerCase().startsWith('ms')
    );

    if (malayVoice) {
      utterance.voice = malayVoice;
      utterance.lang = malayVoice.lang;
    } else {
      utterance.lang = 'ms-MY';
    }

    window.speechSynthesis.speak(utterance);
  } catch {
    // ignore speech synthesis errors
  }
}

export const PUJIAN_MALAYSIA = [
  'Syabas, adik pandai!',
  'Bagusnya, jawapan adik betul!',
  'Wah, hebat sekali!',
  'Tepat sekali, teruskan usaha!',
  'Tahniah, adik bijak suku kata!',
  'Mantap, adik memang cekap!',
];

export const BIMBINGAN_MALAYSIA = [
  'Cuba lagi ya, adik pasti boleh!',
  'Jangan putus asa, mari cuba sekali lagi!',
  'Tengok gambar elok-elok dan cuba lagi ya!',
  'Sikit lagi tu, mari cuba suku kata yang lain!',
];

export function beriPujianRawak() {
  const pujian = PUJIAN_MALAYSIA[Math.floor(Math.random() * PUJIAN_MALAYSIA.length)];
  sebutPerkataan(pujian, 0.95);
  return pujian;
}

export function beriBimbinganRawak() {
  const bimbingan = BIMBINGAN_MALAYSIA[Math.floor(Math.random() * BIMBINGAN_MALAYSIA.length)];
  sebutPerkataan(bimbingan, 0.95);
  return bimbingan;
}
