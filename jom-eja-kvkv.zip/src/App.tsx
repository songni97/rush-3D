/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GameMode, Student } from './types';
import { getStudents, getActiveStudentId } from './utils/storage';
import { Header } from './components/Header';
import { ActivitySheetMode } from './components/ActivitySheetMode';
import { KVKVBuilderMode } from './components/KVKVBuilderMode';
import { DiagnosticQuizMode } from './components/DiagnosticQuizMode';
import { FlashcardsMode } from './components/FlashcardsMode';
import { TeacherDashboard } from './components/TeacherDashboard';
import { StudentProfileModal } from './components/StudentProfileModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { Sparkles, Heart } from 'lucide-react';

export default function App() {
  const [currentMode, setCurrentMode] = useState<GameMode>('lembaran');
  const [students, setStudents] = useState<Student[]>(getStudents());
  const [activeStudentId, setActiveStudentId] = useState<string>(getActiveStudentId());
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showStudentModal, setShowStudentModal] = useState(false);
  const [showTeacherDashboard, setShowTeacherDashboard] = useState(false);

  // Sync active student
  const activeStudent =
    students.find((s) => s.id === activeStudentId) || students[0] || {
      id: 'm-001',
      name: 'Adik Aiman',
      className: '2 Cemerlang',
      avatar: '👦🏻',
      stars: 0,
      totalScore: 0,
      badges: [],
      lastActive: new Date().toISOString(),
    };

  const handleRefreshStudentData = () => {
    const updated = getStudents();
    setStudents(updated);
  };

  const handleStudentSelectedFromDashboard = (studentId: string) => {
    setActiveStudentId(studentId);
    handleRefreshStudentData();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-blue-50/40 to-amber-50/30 flex flex-col font-century text-slate-800">
      {/* App Header & Navigation */}
      <Header
        currentMode={currentMode}
        onSelectMode={setCurrentMode}
        activeStudent={activeStudent}
        onOpenStudentModal={() => setShowStudentModal(true)}
        onOpenTeacherDashboard={() => setShowTeacherDashboard(true)}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
      />

      {/* Main Educational Play Space */}
      <main className="flex-1 py-4 sm:py-6">
        {currentMode === 'lembaran' && (
          <ActivitySheetMode
            activeStudent={activeStudent}
            soundEnabled={soundEnabled}
            onStudentUpdated={handleRefreshStudentData}
          />
        )}

        {currentMode === 'cantum' && (
          <KVKVBuilderMode
            activeStudent={activeStudent}
            soundEnabled={soundEnabled}
            onStudentUpdated={handleRefreshStudentData}
          />
        )}

        {currentMode === 'kuiz' && (
          <DiagnosticQuizMode
            activeStudent={activeStudent}
            soundEnabled={soundEnabled}
            onStudentUpdated={handleRefreshStudentData}
          />
        )}

        {currentMode === 'kad' && (
          <FlashcardsMode soundEnabled={soundEnabled} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white/80 border-t border-sky-100 py-4 px-4 text-center text-xs text-slate-500 font-medium">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-slate-600">
            <span>Aplikasi Interaktif Bijak KVKV</span>
            <span>•</span>
            <span className="text-sky-700 font-bold">Pemulihan Khas Bahasa Melayu</span>
          </div>

          <div className="flex items-center gap-1 text-slate-400">
            <span>Digubal dengan tulisan Century Gothic untuk kemudahan murid mengeja</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      {showStudentModal && (
        <StudentProfileModal
          activeStudent={activeStudent}
          onClose={() => setShowStudentModal(false)}
          onStudentChanged={(st) => {
            setActiveStudentId(st.id);
            handleRefreshStudentData();
          }}
        />
      )}

      {showTeacherDashboard && (
        <TeacherDashboard
          onClose={() => setShowTeacherDashboard(false)}
          onStudentSelected={handleStudentSelectedFromDashboard}
        />
      )}

      {/* PWA Offline Banner */}
      <OfflineIndicator />
    </div>
  );
}
